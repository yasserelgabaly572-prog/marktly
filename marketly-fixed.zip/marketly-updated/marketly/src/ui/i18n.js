const dict = {
  en: {
    st_placed: 'Received', st_confirmed: 'Confirmed', st_packed: 'Packed', st_out_for_delivery: 'Out for delivery', st_delivered: 'Delivered', st_delivery_failed: 'Delivery failed', st_cancelled: 'Cancelled',
    role_customer: 'Customer', role_employee: 'Employee', role_delivery: 'Delivery worker',
    invoice: 'Print / download invoice', invoicePopupBlocked: 'Allow pop-ups to open the invoice for printing.', invoiceLoading: 'Preparing invoice…', invoiceFailed: 'Could not prepare the invoice.',
    order: 'Order', order_one: 'order', order_other: 'orders', recently: 'Recently placed', cod: 'Cash on delivery', paid: 'Paid', due: 'Due on delivery', deliveryPay: 'Delivery pay',
    noPhone: 'No phone', noAddress: 'No address', contactLoading: 'Loading contact details…', contactHidden: 'Customer contact details appear after you take this task.', contactFailed: 'Contact details unavailable.',
    takeTask: 'Take this task', startDelivery: 'Start delivery', markDelivered: 'Mark delivered', deliveryFailed: 'Delivery failed',
    confirmOrder: 'Confirm order', markPacked: 'Mark packed', chooseWorker: 'Choose delivery worker', noWorkers: 'No registered delivery workers', assign: 'Assign', reassign: 'Reassign', saving: 'Saving…', assigned: 'Assigned',
    makeAvailable: 'Make available to drivers', cancelOrder: 'Cancel order', cancelConfirm: 'Cancel this order?', cancelFailed: 'Could not cancel this order.',
    historyEmpty: 'Your orders will appear here.', noActive: 'No active orders right now.', staffDeliveryTitle: 'Delivery queue', staffDeliveryDesc: 'Orders assigned to you for delivery.', staffTitle: 'Order management', staffDesc: 'Review and prepare customer orders.',
    notSet: 'Not set', there: 'there',
    statToday: 'Orders today', statRevenue: 'Delivered revenue today', statLate: 'Waiting over 24h', statTop: 'Top products',
    price: 'Price (USD)', stockQty: 'Stock quantity', save: 'Save changes', saved: 'Saved', invalid: 'Enter a valid price and whole stock quantity.', saveFailed: 'Could not save. Check Firestore rules.', savingNow: 'Saving…',
    unitsNow: '{n} units currently in stock', invSummary: '{p} products · {u} units in stock', bulk: 'Set empty stock to 10', notSaved: 'Not in store yet',
    inStock: '{n} in stock', noMatch: 'No products match your search.', stockAlert: 'Not enough stock for this item.', cartLimit: 'A single order can contain up to 8 different items.', lineLimit: 'Maximum 20 units of one item per order.',
    placed: 'Order placed. Pay cash to the delivery worker when it arrives.', checkoutFail: 'We could not save this order. Please try again.', orderValidationFailed: 'The order could not be validated. Refresh the store and check your delivery details.', priceChanged: 'A product price changed. Refresh the store and review your cart.', productMissing: 'A product is no longer available. Refresh the store and try again.', stockUnavailable: 'The available stock changed. Review your cart and try again.',
    cannotUpdate: 'Could not update this order.', taken: 'This task is no longer available.', takeFail: 'Could not accept this task. It may have been taken by another worker.',
    appearance: 'Appearance', appearanceEyebrow: 'APPEARANCE', language: 'Language'
  },
  ar: {
    st_placed: 'تم الاستلام', st_confirmed: 'تم التأكيد', st_packed: 'تم التجهيز', st_out_for_delivery: 'في الطريق', st_delivered: 'تم التسليم', st_delivery_failed: 'فشل التوصيل', st_cancelled: 'ملغي',
    role_customer: 'عميل', role_employee: 'موظف', role_delivery: 'عامل توصيل',
    invoice: 'طباعة / تنزيل الفاتورة', invoicePopupBlocked: 'اسمح بالنوافذ المنبثقة لفتح الفاتورة وطباعتها.', invoiceLoading: 'جارٍ تجهيز الفاتورة…', invoiceFailed: 'تعذّر تجهيز الفاتورة.',
    order: 'طلب', order_one: 'طلب', order_other: 'طلبات', recently: 'تم الطلب مؤخرًا', cod: 'الدفع عند الاستلام', paid: 'مدفوع', due: 'مستحق عند التسليم', deliveryPay: 'مبلغ التوصيل',
    noPhone: 'لا يوجد هاتف', noAddress: 'لا يوجد عنوان', contactLoading: 'جارٍ تحميل بيانات العميل…', contactHidden: 'تظهر بيانات العميل بعد استلام المهمة.', contactFailed: 'بيانات العميل غير متاحة.',
    takeTask: 'استلام المهمة', startDelivery: 'بدء التوصيل', markDelivered: 'تم التسليم', deliveryFailed: 'فشل التوصيل',
    confirmOrder: 'تأكيد الطلب', markPacked: 'تم التجهيز', chooseWorker: 'اختر عامل توصيل', noWorkers: 'لا يوجد عمال توصيل مسجلون', assign: 'تعيين', reassign: 'إعادة تعيين', saving: 'جارٍ الحفظ…', assigned: 'تم التعيين',
    makeAvailable: 'إتاحة للعاملين', cancelOrder: 'إلغاء الطلب', cancelConfirm: 'هل تريد إلغاء هذا الطلب؟', cancelFailed: 'تعذّر إلغاء الطلب.',
    historyEmpty: 'ستظهر طلباتك هنا.', noActive: 'لا توجد طلبات نشطة الآن.', staffDeliveryTitle: 'قائمة التوصيل', staffDeliveryDesc: 'الطلبات المسندة إليك للتوصيل.', staffTitle: 'إدارة الطلبات', staffDesc: 'راجع طلبات العملاء وجهّزها.',
    notSet: 'غير محدد', there: 'بك',
    statToday: 'طلبات اليوم', statRevenue: 'إيراد المسلَّم اليوم', statLate: 'ينتظر أكثر من 24 ساعة', statTop: 'الأكثر مبيعًا',
    price: 'السعر (دولار)', stockQty: 'كمية المخزون', save: 'حفظ التغييرات', saved: 'تم الحفظ', invalid: 'أدخل سعرًا صحيحًا وكمية مخزون صحيحة.', saveFailed: 'تعذّر الحفظ. تحقق من قواعد Firestore.', savingNow: 'جارٍ الحفظ…',
    unitsNow: '{n} وحدة في المخزون حاليًا', invSummary: '{p} منتج · {u} وحدة في المخزون', bulk: 'ضبط المخزون الفارغ على 10', notSaved: 'غير مضاف للمتجر بعد',
    inStock: '{n} متوفر', noMatch: 'لا توجد منتجات تطابق بحثك.', stockAlert: 'الكمية غير متوفرة في المخزون', cartLimit: 'يمكن أن يحتوي الطلب الواحد على 8 منتجات مختلفة كحد أقصى.', lineLimit: 'الحد الأقصى 20 وحدة من المنتج الواحد في الطلب.',
    placed: 'تم إرسال الطلب. ادفع نقدًا لمندوب التوصيل عند وصوله.', checkoutFail: 'تعذّر حفظ الطلب. حاول مرة أخرى.', orderValidationFailed: 'تعذّر التحقق من الطلب. حدّث المتجر وتأكد من بيانات التوصيل.', priceChanged: 'تغيّر سعر أحد المنتجات. حدّث المتجر وراجع سلة التسوق.', productMissing: 'أحد المنتجات لم يعد متاحًا. حدّث المتجر وحاول مجددًا.', stockUnavailable: 'تغيّرت الكمية المتاحة. راجع سلة التسوق وحاول مجددًا.',
    cannotUpdate: 'تعذّر تحديث الطلب.', taken: 'هذه المهمة لم تعد متاحة.', takeFail: 'تعذّر استلام المهمة. ربما استلمها عامل آخر.',
    appearance: 'إعدادات الشكل', appearanceEyebrow: 'المظهر', language: 'اللغة'
  }
};
Object.assign(dict.en, { retention: 'Completed orders and their invoices are deleted 30 days after placement. Active orders remain until they are completed.', deletesOn: 'Eligible for deletion on {date}' });
Object.assign(dict.ar, { retention: 'تُحذف الطلبات المكتملة وفواتيرها بعد 30 يومًا من إنشائها. تبقى الطلبات النشطة حتى اكتمالها.', deletesOn: 'موعد إتاحة الحذف {date}' });
dict.fr = {
  st_placed: 'Reçue', st_confirmed: 'Confirmée', st_packed: 'Préparée', st_out_for_delivery: 'En cours de livraison', st_delivered: 'Livrée', st_delivery_failed: 'Échec de livraison', st_cancelled: 'Annulée',
  role_customer: 'Client', role_employee: 'Employé', role_delivery: 'Livreur',
  order: 'Commande', order_one: 'commande', order_other: 'commandes', recently: 'Commandée récemment', cod: 'Paiement à la livraison', paid: 'Payée', due: 'À payer à la livraison', deliveryPay: 'Rémunération de livraison',
  noPhone: 'Pas de téléphone', noAddress: 'Pas d’adresse', contactLoading: 'Chargement des coordonnées…', contactHidden: 'Les coordonnées du client apparaissent après la prise en charge de cette tâche.', contactFailed: 'Coordonnées indisponibles.',
  takeTask: 'Prendre cette tâche', startDelivery: 'Démarrer la livraison', markDelivered: 'Marquer comme livrée', deliveryFailed: 'Échec de livraison',
  confirmOrder: 'Confirmer la commande', markPacked: 'Marquer comme préparée', chooseWorker: 'Choisir un livreur', noWorkers: 'Aucun livreur enregistré', assign: 'Assigner', reassign: 'Réassigner', saving: 'Enregistrement…', assigned: 'Assignée',
  makeAvailable: 'Rendre disponible aux livreurs', cancelOrder: 'Annuler la commande', cancelConfirm: 'Annuler cette commande ?', cancelFailed: 'Impossible d’annuler cette commande.',
  historyEmpty: 'Vos commandes apparaîtront ici.', noActive: 'Aucune commande active pour le moment.', staffDeliveryTitle: 'File de livraison', staffDeliveryDesc: 'Commandes qui vous sont assignées.', staffTitle: 'Gestion des commandes', staffDesc: 'Vérifiez et préparez les commandes des clients.',
  notSet: 'Non défini', there: 'vous',
  statToday: 'Commandes du jour', statRevenue: 'Chiffre d’affaires livré aujourd’hui', statLate: 'En attente depuis plus de 24 h', statTop: 'Produits les plus vendus',
  price: 'Prix (USD)', stockQty: 'Quantité en stock', save: 'Enregistrer', saved: 'Enregistré', invalid: 'Saisissez un prix valide et une quantité entière.', saveFailed: 'Échec de l’enregistrement. Vérifiez les règles Firestore.', savingNow: 'Enregistrement…',
  unitsNow: '{n} unités actuellement en stock', invSummary: '{p} produits · {u} unités en stock', bulk: 'Mettre le stock vide à 10', notSaved: 'Pas encore dans la boutique',
  inStock: '{n} en stock', noMatch: 'Aucun produit ne correspond à votre recherche.', stockAlert: 'Stock insuffisant pour cet article.', cartLimit: 'Une commande peut contenir au maximum 8 articles différents.', lineLimit: 'Maximum 20 unités d’un même article par commande.',
  placed: 'Commande passée. Payez en espèces au livreur à son arrivée.', checkoutFail: 'Impossible d’enregistrer cette commande. Réessayez.', orderValidationFailed: 'La commande n’a pas pu être validée. Actualisez la boutique et vérifiez vos coordonnées.', priceChanged: 'Le prix d’un article a changé. Actualisez la boutique et vérifiez votre panier.', productMissing: 'Un article n’est plus disponible. Actualisez la boutique et réessayez.', stockUnavailable: 'Le stock disponible a changé. Vérifiez votre panier et réessayez.',
  cannotUpdate: 'Impossible de mettre à jour cette commande.', taken: 'Cette tâche n’est plus disponible.', takeFail: 'Impossible d’accepter cette tâche. Un autre livreur l’a peut-être prise.',
  appearance: 'Apparence', appearanceEyebrow: 'APPARENCE', language: 'Langue',
  invoice: 'Imprimer / télécharger la facture', invoicePopupBlocked: 'Autorisez les fenêtres pop-up pour imprimer la facture.', invoiceLoading: 'Préparation de la facture…', invoiceFailed: 'Impossible de préparer la facture.',
  retention: 'Les commandes terminées et leurs factures sont supprimées 30 jours après leur création. Les commandes actives sont conservées jusqu’à leur clôture.', deletesOn: 'Suppression possible le {date}'
};
dict.es = {
  st_placed: 'Recibido', st_confirmed: 'Confirmado', st_packed: 'Preparado', st_out_for_delivery: 'En reparto', st_delivered: 'Entregado', st_delivery_failed: 'Entrega fallida', st_cancelled: 'Cancelado',
  role_customer: 'Cliente', role_employee: 'Empleado', role_delivery: 'Repartidor',
  order: 'Pedido', order_one: 'pedido', order_other: 'pedidos', recently: 'Realizado recientemente', cod: 'Pago contra reembolso', paid: 'Pagado', due: 'Pendiente de pago en la entrega', deliveryPay: 'Pago por reparto',
  noPhone: 'Sin teléfono', noAddress: 'Sin dirección', contactLoading: 'Cargando datos de contacto…', contactHidden: 'Los datos del cliente aparecen cuando aceptas esta tarea.', contactFailed: 'Datos de contacto no disponibles.',
  takeTask: 'Aceptar esta tarea', startDelivery: 'Iniciar entrega', markDelivered: 'Marcar como entregado', deliveryFailed: 'Entrega fallida',
  confirmOrder: 'Confirmar pedido', markPacked: 'Marcar como preparado', chooseWorker: 'Elegir repartidor', noWorkers: 'No hay repartidores registrados', assign: 'Asignar', reassign: 'Reasignar', saving: 'Guardando…', assigned: 'Asignado',
  makeAvailable: 'Poner a disposición de los repartidores', cancelOrder: 'Cancelar pedido', cancelConfirm: '¿Cancelar este pedido?', cancelFailed: 'No se pudo cancelar este pedido.',
  historyEmpty: 'Tus pedidos aparecerán aquí.', noActive: 'No hay pedidos activos ahora.', staffDeliveryTitle: 'Cola de reparto', staffDeliveryDesc: 'Pedidos asignados a ti para entregar.', staffTitle: 'Gestión de pedidos', staffDesc: 'Revisa y prepara los pedidos de los clientes.',
  notSet: 'No definido', there: 'ahí',
  statToday: 'Pedidos de hoy', statRevenue: 'Ingresos entregados hoy', statLate: 'Esperando más de 24 h', statTop: 'Productos más vendidos',
  price: 'Precio (USD)', stockQty: 'Cantidad en stock', save: 'Guardar cambios', saved: 'Guardado', invalid: 'Introduce un precio válido y una cantidad entera.', saveFailed: 'No se pudo guardar. Revisa las reglas de Firestore.', savingNow: 'Guardando…',
  unitsNow: '{n} unidades en stock actualmente', invSummary: '{p} productos · {u} unidades en stock', bulk: 'Poner el stock vacío en 10', notSaved: 'Aún no está en la tienda',
  inStock: '{n} en stock', noMatch: 'Ningún producto coincide con tu búsqueda.', stockAlert: 'No hay stock suficiente de este artículo.', cartLimit: 'Un pedido puede tener como máximo 8 artículos distintos.', lineLimit: 'Máximo 20 unidades de un mismo artículo por pedido.',
  placed: 'Pedido realizado. Paga en efectivo al repartidor cuando llegue.', checkoutFail: 'No pudimos guardar este pedido. Inténtalo de nuevo.', orderValidationFailed: 'No se pudo validar el pedido. Actualiza la tienda y revisa los datos de entrega.', priceChanged: 'El precio de un producto cambió. Actualiza la tienda y revisa el carrito.', productMissing: 'Un producto ya no está disponible. Actualiza la tienda e inténtalo de nuevo.', stockUnavailable: 'El stock disponible cambió. Revisa el carrito e inténtalo de nuevo.',
  cannotUpdate: 'No se pudo actualizar este pedido.', taken: 'Esta tarea ya no está disponible.', takeFail: 'No se pudo aceptar la tarea. Quizá otro repartidor la tomó.',
  appearance: 'Apariencia', appearanceEyebrow: 'APARIENCIA', language: 'Idioma',
  invoice: 'Imprimir / descargar factura', invoicePopupBlocked: 'Permite las ventanas emergentes para imprimir la factura.', invoiceLoading: 'Preparando la factura…', invoiceFailed: 'No se pudo preparar la factura.',
  retention: 'Los pedidos completados y sus facturas se eliminan 30 días después de su creación. Los pedidos activos se conservan hasta que se completen.', deletesOn: 'Se puede eliminar el {date}'
};
export const lang = () => localStorage.getItem('marketlyLanguage') || 'en';
export const isAr = () => lang() === 'ar';
export function tr(key, vars = {}) {
  const text = (dict[lang()] || dict.en)[key] ?? dict.en[key] ?? key;
  return text.replace(/\{(\w+)\}/g, (_, name) => vars[name] ?? '');
}

// Static page text (Arabic only; other languages keep the English markup).
const texts = [
  ['#dashboardTab', 'لوحة التحكم'], ['#shopTab', 'المتجر'], ['#staffLogout', 'تسجيل الخروج'],
  ['#dashboardView .dashboard-heading .eyebrow', 'ماركتلي الخاص بك'],
  ['#dashboardView .dashboard-heading h1', 'أهلاً، ', true],
  ['#dashboardView .dashboard-heading p:not(.eyebrow)', 'حسابك جاهز. تصفح المتجر أو راجع بيانات ملفك.'],
  ['.dashboard-cards article:nth-child(1) p', 'الحساب'], ['.dashboard-cards article:nth-child(2) p', 'الدولة'], ['.dashboard-cards article:nth-child(3) p', 'عناصر السلة'],
  ['#browseShopButton', 'تصفح المتجر ', true],
  ['#dashboardView .order-history .eyebrow', 'مشترياتك'], ['#dashboardView .order-history h2', 'متابعة الطلب'],
  ['#completedOrdersButton', 'الطلبات السابقة ', true], ['#completedOrdersEyebrow', 'مشترياتك'], ['#completedOrdersTitle', 'الطلبات السابقة'],
  ['#staffView .order-history .history-heading h2', 'الطلبات النشطة'],
  ['#inventoryPanel .eyebrow', 'إدارة الكتالوج'], ['#inventoryPanel h2', 'المخزون والأسعار'], ['#inventoryPanel .inventory-help', 'حدّث السعر والمخزون المتاح لكل منتج.'],
  ['#checkoutForm .eyebrow', 'بيانات التوصيل'], ['#checkoutTitle', 'الدفع عند الاستلام'], ['#checkoutForm .checkout-note', 'ادفع لمندوب التوصيل عند وصول طلبك.'],
  ['#paymentMethodLabel', 'وسيلة الدفع'], ['#codOptionLabel', 'الدفع عند الاستلام'], ['#codOptionNote', 'ادفع عند وصول طلبك'],
  ['#visaOptionNote', 'قريبًا — جارٍ تجهيز الدفع بالبطاقة'], ['#visaComingSoon', 'قريبًا'],
  ['#checkoutForm label:nth-of-type(1)', 'رقم الهاتف', true], ['#checkoutForm label:nth-of-type(2)', 'عنوان التوصيل', true],
  ['#checkoutForm button[type="submit"]', 'تأكيد الطلب ', true], ['#addButton', 'أضف إلى السلة ', true],
  ['#supportChat header strong', 'دعم ماركتلي'], ['#supportChat header small', 'إجابات سريعة في أي وقت'], ['#supportLauncher span', 'الدعم']
];
const placeholders = [['#searchInput', 'ابحث عن منتجات وعلامات وأكثر'], ['#chatInput', 'اكتب سؤالك…'], ['#deliveryPhone', '01xxxxxxxxx'], ['#deliveryAddress', 'الشارع، المبنى، المنطقة، المدينة']];
const originals = new WeakMap();
export function applyStaticText() {
  const ar = isAr();
  texts.forEach(([selector, arabic, firstNode]) => document.querySelectorAll(selector).forEach(el => {
    const node = firstNode ? el.firstChild : el;
    if (!node) return;
    if (!originals.has(node)) originals.set(node, node.textContent);
    node.textContent = ar ? arabic : originals.get(node);
  }));
  placeholders.forEach(([selector, arabic]) => {
    const el = document.querySelector(selector); if (!el) return;
    if (!originals.has(el)) originals.set(el, el.getAttribute('placeholder') || '');
    el.setAttribute('placeholder', ar ? arabic : originals.get(el));
  });
}
window.addEventListener('marketly:language-changed', applyStaticText);
applyStaticText();

Object.assign(dict.en, { outOfStock: 'Out of stock', lowStock: 'Only {n} left', sortDefault: 'Sort: featured', sortLow: 'Price: low to high', sortHigh: 'Price: high to low', codCartNote: 'Cash on delivery: pay when your order arrives.', backToShop: 'Back to shop' });
Object.assign(dict.ar, { outOfStock: 'نفد', lowStock: 'بقي {n} فقط', sortDefault: 'الترتيب: المميز', sortLow: 'السعر: من الأقل', sortHigh: 'السعر: من الأعلى', codCartNote: 'الدفع عند الاستلام: ادفع عند وصول طلبك.', backToShop: 'العودة للمتجر' });
Object.assign(dict.fr, { outOfStock: 'Épuisé', lowStock: 'Plus que {n}', sortDefault: 'Tri : sélection', sortLow: 'Prix croissant', sortHigh: 'Prix décroissant', codCartNote: 'Paiement à la livraison.', backToShop: 'Retour à la boutique' });
Object.assign(dict.es, { outOfStock: 'Agotado', lowStock: 'Quedan {n}', sortDefault: 'Orden: destacados', sortLow: 'Precio: menor a mayor', sortHigh: 'Precio: mayor a menor', codCartNote: 'Pago contra reembolso.', backToShop: 'Volver a la tienda' });
