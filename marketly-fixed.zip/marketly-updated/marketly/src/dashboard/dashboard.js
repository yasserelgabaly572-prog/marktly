import { auth, db } from '../firebase/firebase.js';
import { collection, collectionGroup, getDocs, query, where, orderBy, onSnapshot, runTransaction, increment, updateDoc, getDoc, doc, setDoc, serverTimestamp, writeBatch, Timestamp } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';
import { formatMoney, setCurrencyForCountry } from '../store/currency.js';
import { tr, isAr } from '../ui/i18n.js';

const authScreen = document.querySelector('#authScreen');
const shopApp = document.querySelector('#shopApp');
const dashboardView = document.querySelector('#dashboardView');
const staffView = document.querySelector('#staffView');
const storeView = document.querySelector('.topbar');
let signedInUser;
let staffRole = '';
let catalogProducts = [];
const contactCache = new Map();
const migrated = new Set();
const expiryBackfills = new Set();
const expiredDeletes = new Set();
const toDate = value => value?.toDate?.() || (value ? new Date(value) : null);
const RETENTION_SECONDS = 30 * 24 * 60 * 60;
const TERMINAL_STATUSES = ['delivered', 'cancelled', 'delivery_failed'];
// Shown on invoices. Fill in the seller details your invoices need (name, address, tax number).
const STORE_INFO = { name: 'Marketly', address: '', taxId: '' };

export async function showDashboard(user, profile = {}, role = 'customer') {
  signedInUser = user;
  staffRole = role;
  authScreen.classList.add('hidden');
  shopApp.classList.remove('hidden');
  document.querySelector('#accountName').textContent = `${user.email || ''} · ${roleLabel(role)}`;
  if (role !== 'customer') {
    document.querySelector('#staffLogout').classList.remove('hidden');
    document.querySelector('#dashboardTab').classList.add('hidden');
    document.querySelector('#shopTab').classList.add('hidden');
    document.querySelector('#logoutButton').classList.add('hidden');
    staffView.classList.remove('hidden');
    dashboardView.classList.add('hidden');
    document.querySelectorAll('.shop-app > .welcome, .shop-app > .promo-media, .shop-app > .catalog-section, .shop-app > footer').forEach(node => node.classList.add('hidden'));
    storeView.classList.add('hidden');
    setStaffHeadings();
    document.querySelector('#inventoryPanel').classList.toggle('hidden', role === 'delivery');
    if (role !== 'delivery' && catalogProducts.length) renderInventory(catalogProducts);
    await loadStaffOrders();
    return;
  }
  document.querySelector('#dashboardTab').classList.remove('hidden');
  document.querySelector('#staffLogout').classList.add('hidden');
  document.querySelector('#shopTab').classList.remove('hidden');
  document.querySelector('#logoutButton').classList.remove('hidden');
  document.querySelector('#dashboardName').textContent = profile.displayName || user.displayName || user.email?.split('@')[0] || tr('there');
  document.querySelector('#dashboardEmail').textContent = user.email || '—';
  document.querySelector('#dashboardCountry').textContent = profile.country ? new Intl.DisplayNames([isAr() ? 'ar' : 'en'], { type: 'region' }).of(profile.country) : tr('notSet');
  showView('dashboard');
  await setCurrencyForCountry(profile.country || 'US');
  await loadOrderHistory(user.uid);
}
function roleLabel(role) { return tr(role === 'delivery' ? 'role_delivery' : role === 'employee' || role === 'admin' ? 'role_employee' : 'role_customer'); }
function setStaffHeadings() {
  document.querySelector('#staffRoleLabel').textContent = roleLabel(staffRole).toUpperCase();
  document.querySelector('#staffTitle').textContent = staffRole === 'delivery' ? tr('staffDeliveryTitle') : tr('staffTitle');
  document.querySelector('#staffDescription').textContent = staffRole === 'delivery' ? tr('staffDeliveryDesc') : tr('staffDesc');
}
function statusText(status) { return tr('st_' + (status || 'placed')); }
function statusBadge(status) { const badge = document.createElement('span'); badge.className = `status-badge status-${status || 'placed'}`; badge.textContent = statusText(status); return badge; }
function money(order) { return new Intl.NumberFormat(navigator.language || 'en', { style: 'currency', currency: order.currency || 'USD' }).format(Number(order.total || 0)); }
function orderDate(order) { return order.createdAt?.toDate?.()?.toLocaleString() || tr('recently'); }
let unsub = null, workers = [];
let availableUnsub = null;
const STEPS = ['placed', 'confirmed', 'packed', 'out_for_delivery', 'delivered'];
function listen(q, render) { unsub?.(); unsub = onSnapshot(q, render, error => console.error('Orders listener failed', error)); }
function btn(label, fn, secondary) { const b = document.createElement('button'); b.className = 'small-action' + (secondary ? ' secondary' : ''); b.textContent = label; b.addEventListener('click', fn); return b; }
function progress(order) {
  const names = isAr() ? ['استلمنا', 'أكدنا', 'جهّزنا', 'في الطريق', 'وصل'] : ['Received', 'Confirmed', 'Packed', 'On the way', 'Delivered'];
  const bad = ['cancelled', 'delivery_failed'].includes(order.status);
  const at = bad ? Math.max(0, ...(order.statusHistory || []).map(h => STEPS.indexOf(h.status))) : STEPS.indexOf(order.status);
  const list = document.createElement('ol'); list.className = 'progress';
  names.forEach((name, i) => { const li = document.createElement('li'); li.textContent = name; li.className = i < at || (i === at && order.status === 'delivered') ? 'done' : i === at ? (bad ? 'bad' : 'current') : ''; list.append(li); });
  return list;
}
function createOrderCard(id, order, staff = false, ref = null) {
  const card = document.createElement('article'); card.className = 'order-card';
  const heading = document.createElement('div'); heading.className = 'order-card-heading';
  const title = document.createElement('strong'); title.textContent = `${tr('order')} ${id.slice(0, 8).toUpperCase()}`;
  const total = document.createElement('strong'); total.textContent = money(order);
  heading.append(title, total);
  const statusLine = document.createElement('div'); statusLine.className = 'order-status-line'; statusLine.append(statusBadge(order.status));
  if (order.paymentMethod === 'cod') { const payment = document.createElement('span'); payment.className = 'payment-badge'; payment.textContent = `${tr('cod')} · ${order.paymentStatus === 'paid' ? tr('paid') : tr('due')}`; statusLine.append(payment); }
  if (staffRole === 'delivery') { const payout = document.createElement('span'); payout.className = 'payment-badge'; payout.textContent = `${tr('deliveryPay')} · ${formatMoney(Number(order.deliveryFeeUsd || 0))}`; statusLine.append(payout); }
  const date = document.createElement('p'); date.className = 'order-date'; date.textContent = orderDate(order) + (!staff && deletionText(order) ? ` · ${deletionText(order)}` : '');
  const items = document.createElement('p'); items.className = 'order-items'; items.textContent = (order.items || []).map(item => `${item.title} × ${item.quantity}`).join(' · ');
  card.append(heading, statusLine, date, progress(order), items);
  const s = order.status;
  if (staff) {
    const detail = document.createElement('p'); detail.className = 'order-date'; card.append(detail); fillContact(detail, ref, order);
    const actions = document.createElement('div'); actions.className = 'order-actions';
    if (staffRole === 'delivery') {
      if (s === 'packed' && !order.assignedTo) actions.append(btn(tr('takeTask'), () => acceptTask(ref, order)));
      if (s === 'packed' && order.assignedTo === signedInUser.uid) actions.append(btn(tr('startDelivery'), () => updateOrder(ref, order, { status: 'out_for_delivery' })));
      if (s === 'out_for_delivery') actions.append(btn(tr('markDelivered'), () => updateOrder(ref, order, { status: 'delivered', paymentStatus: 'paid', deliveredAt: serverTimestamp() })), btn(tr('deliveryFailed'), () => updateOrder(ref, order, { status: 'delivery_failed' }), true));
    } else {
      if (s === 'placed') actions.append(btn(tr('confirmOrder'), () => updateOrder(ref, order, { status: 'confirmed' }, order.inventoryReserved === true ? 0 : -1)));
      if (s === 'confirmed') actions.append(btn(tr('markPacked'), () => updateOrder(ref, order, { status: 'packed' })));
      if (s === 'packed' || s === 'delivery_failed') {
        const pick = document.createElement('select'); pick.className = 'assignee-input'; pick.setAttribute('aria-label', 'Delivery worker');
        pick.innerHTML = `<option value="">${tr('chooseWorker')}</option>`;
        if (!workers.length) { const empty = document.createElement('option'); empty.disabled = true; empty.textContent = tr('noWorkers'); pick.append(empty); }
        workers.forEach(w => { const o = document.createElement('option'); o.value = w.id; o.textContent = w.email || w.name; o.selected = w.id === order.assignedTo; pick.append(o); });
        const assignButton = btn(order.assignedTo ? tr('reassign') : tr('assign'), async () => {
          if (!pick.value) { pick.focus(); return; }
          assignButton.disabled = true;
          const originalLabel = assignButton.textContent;
          assignButton.textContent = tr('saving');
          const saved = await updateOrder(ref, order, { status: 'packed', assignedTo: pick.value });
          assignButton.textContent = saved ? tr('assigned') : originalLabel;
          assignButton.disabled = saved;
        });
        assignButton.disabled = workers.length === 0;
        actions.append(pick, assignButton);
        if (s === 'packed' && order.assignedTo === '') {
          const availableButton = btn(tr('makeAvailable'), () => makeTaskAvailable(ref, availableButton), true);
          actions.append(availableButton);
        }
      }
      if (['placed', 'confirmed', 'packed', 'delivery_failed'].includes(s)) actions.append(btn(tr('cancelOrder'), () => {
        if (confirm(tr('cancelConfirm'))) updateOrder(ref, order, { status: 'cancelled' }, s === 'placed' && order.inventoryReserved !== true ? 0 : 1);
      }, true));
    }
    if (actions.childElementCount) card.append(actions);
  } else {
    const actions = document.createElement('div'); actions.className = 'order-actions';
    if (s === 'placed') actions.append(btn(tr('cancelOrder'), () => cancelOrder(signedInUser.uid, id, order), true));
    actions.append(btn(tr('invoice'), () => printInvoice(id, order), true));
    card.append(actions);
  }
  return card;
}
function loadOrderHistory(uid) {
  const list = document.querySelector('#orderHistoryList'), count = document.querySelector('#orderHistoryCount');
  const completedList = document.querySelector('#completedOrdersList');
  const completedButton = document.querySelector('#completedOrdersButton');
  listen(query(collection(db, 'users', uid, 'orders'), orderBy('createdAt', 'desc')), result => {
    const active = [], completed = [];
    result.forEach(snapshot => {
      const order = snapshot.data();
      const terminal = TERMINAL_STATUSES.includes(order.status);
      const expired = Boolean(order.createdAt?.toMillis) && Date.now() >= order.createdAt.toMillis() + RETENTION_SECONDS * 1000;
      if (expired && terminal) { // only finished orders are ever deleted by the app
        purgeExpiredOrder(snapshot).catch(error => console.warn('Could not delete expired order', error));
        return;
      }
      if (terminal) completed.push(snapshot); else active.push(snapshot);
      if (!order.expiresAt && !expired) backfillExpiry(snapshot).catch(error => console.warn('Could not set order expiry', error));
    });
    count.textContent = `${active.length} ${tr(active.length === 1 ? 'order_one' : 'order_other')}`;
    document.querySelector('#completedOrderCount').textContent = String(completed.length);
    completedButton.classList.toggle('hidden', completed.length === 0);
    list.replaceChildren(); completedList.replaceChildren(); setRetentionNotes();
    if (!active.length) { const empty = document.createElement('p'); empty.className = 'history-empty'; empty.textContent = tr('noActive'); list.append(empty); }
    active.forEach(snapshot => list.append(createOrderCard(snapshot.id, snapshot.data())));
    if (!completed.length) { const empty = document.createElement('p'); empty.className = 'history-empty'; empty.textContent = tr('historyEmpty'); completedList.append(empty); }
    completed.forEach(snapshot => completedList.append(createOrderCard(snapshot.id, snapshot.data())));
  });
}
async function purgeExpiredOrder(snapshot) {
  if (expiredDeletes.has(snapshot.ref.path)) return;
  expiredDeletes.add(snapshot.ref.path);
  try {
    const batch = writeBatch(db);
    batch.delete(snapshot.ref);
    batch.delete(doc(snapshot.ref, 'private', 'contact'));
    await batch.commit();
  } finally { expiredDeletes.delete(snapshot.ref.path); }
}
async function backfillExpiry(snapshot) {
  if (expiryBackfills.has(snapshot.ref.path)) return;
  const order = snapshot.data(), createdAt = order.createdAt;
  if (!createdAt?.seconds || order.expiresAt) return;
  expiryBackfills.add(snapshot.ref.path);
  const expiresAt = new Timestamp(createdAt.seconds + RETENTION_SECONDS, createdAt.nanoseconds || 0);
  try {
    const batch = writeBatch(db);
    batch.update(snapshot.ref, { expiresAt });
    const contactRef = doc(snapshot.ref, 'private', 'contact');
    const contact = await getDoc(contactRef);
    if (contact.exists() && !contact.data().expiresAt) batch.update(contactRef, { expiresAt });
    await batch.commit();
  } finally { expiryBackfills.delete(snapshot.ref.path); }
}
function invoiceEscape(value = '') { return String(value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]); }
async function printInvoice(id, order) {
  const invoiceWindow = window.open('', '_blank');
  if (!invoiceWindow) { alert(tr('invoicePopupBlocked')); return; }
  invoiceWindow.document.write(`<title>${invoiceEscape(tr('invoice'))}</title><p>${invoiceEscape(tr('invoiceLoading'))}</p>`);
  try {
    const snapshot = await getDoc(doc(db, 'users', signedInUser.uid, 'orders', id, 'private', 'contact'));
    const contact = snapshot.exists() ? snapshot.data() : {};
    const locale = isAr() ? 'ar' : navigator.language || 'en';
    const currency = /^[A-Z]{3}$/.test(order.currency || '') ? order.currency : 'USD';
    const rate = Number(order.exchangeRate) > 0 ? Number(order.exchangeRate) : 1;
    const format = amount => new Intl.NumberFormat(locale, { style: 'currency', currency }).format(Number(amount || 0) * rate);
    const rows = (order.items || []).map(item => `<tr><td>${invoiceEscape(item.title)}</td><td>${Number(item.quantity) || 0}</td><td>${format(item.unitPriceUsd)}</td><td>${format(Number(item.unitPriceUsd) * Number(item.quantity))}</td></tr>`).join('');
    const lang = isAr() ? 'ar' : 'en';
    const labels = isAr()
      ? { title: 'فاتورة', number: 'رقم الطلب', date: 'التاريخ', status: 'الحالة', customer: 'بيانات العميل', name: 'الاسم', phone: 'الهاتف', address: 'العنوان', item: 'المنتج', qty: 'الكمية', price: 'سعر الوحدة', amount: 'الإجمالي', subtotal: 'المجموع الفرعي', delivery: 'التوصيل', total: 'المبلغ الإجمالي', print: 'طباعة / حفظ PDF', taxId: 'الرقم الضريبي' }
      : { title: 'Invoice', number: 'Order', date: 'Date', status: 'Status', customer: 'Customer details', name: 'Name', phone: 'Phone', address: 'Address', item: 'Item', qty: 'Qty', price: 'Unit price', amount: 'Amount', subtotal: 'Subtotal', delivery: 'Delivery', total: 'Total', print: 'Print / Save PDF', taxId: 'Tax ID' };
    const sellerLines = [STORE_INFO.address, STORE_INFO.taxId && `${labels.taxId}: ${STORE_INFO.taxId}`].filter(Boolean).map(line => `<p class="muted">${invoiceEscape(line)}</p>`).join('');
    const documentHtml = `<!doctype html><html lang="${lang}" dir="${isAr() ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><title>${invoiceEscape(labels.title)} ${invoiceEscape(id.slice(0, 8).toUpperCase())}</title><style>body{font:15px Arial,sans-serif;color:#17251f;max-width:850px;margin:40px auto;padding:0 24px}header,.row{display:flex;justify-content:space-between;gap:20px}h1{margin:0 0 8px}h2{font-size:18px;margin:28px 0 10px}.muted{color:#607168}table{width:100%;border-collapse:collapse;margin-top:24px}th,td{text-align:start;padding:12px 8px;border-bottom:1px solid #dfe5df}th{background:#f3f6f2}.totals{width:min(360px,100%);margin:20px 0 0 auto}.totals p{display:flex;justify-content:space-between;border-bottom:1px solid #e4e9e4;padding:8px 0}.grand{font-size:20px;font-weight:bold}.print{margin:18px 0;padding:12px 18px;border:0;background:#14211d;color:#fff;font-weight:bold;cursor:pointer}@media print{body{margin:0 auto}.print{display:none}}</style></head><body><header><div><h1>${invoiceEscape(STORE_INFO.name)}</h1><p class="muted">${invoiceEscape(labels.title)}</p>${sellerLines}</div><div><strong>${invoiceEscape(labels.number)} ${invoiceEscape(id.slice(0, 8).toUpperCase())}</strong><p>${invoiceEscape(labels.date)}: ${invoiceEscape(orderDate(order))}</p><p>${invoiceEscape(labels.status)}: ${invoiceEscape(statusText(order.status))}</p></div></header><h2>${invoiceEscape(labels.customer)}</h2><p>${invoiceEscape(labels.name)}: ${invoiceEscape(contact.customerName || '')}</p><p>${invoiceEscape(contact.customerEmail || signedInUser.email || '')}</p><p>${invoiceEscape(labels.phone)}: ${invoiceEscape(contact.phone || '')}</p><p>${invoiceEscape(labels.address)}: ${invoiceEscape(contact.address || '')}</p><table><thead><tr><th>${invoiceEscape(labels.item)}</th><th>${invoiceEscape(labels.qty)}</th><th>${invoiceEscape(labels.price)}</th><th>${invoiceEscape(labels.amount)}</th></tr></thead><tbody>${rows}</tbody></table><div class="totals"><p><span>${invoiceEscape(labels.subtotal)}</span><strong>${format(order.subtotalUsd)}</strong></p><p><span>${invoiceEscape(labels.delivery)}</span><strong>${format(order.deliveryFeeUsd)}</strong></p><p class="grand"><span>${invoiceEscape(labels.total)}</span><strong>${format(order.totalUsd)}</strong></p></div><button class="print" type="button">${invoiceEscape(labels.print)}</button></body></html>`;
    invoiceWindow.document.open(); invoiceWindow.document.write(documentHtml); invoiceWindow.document.close();
    invoiceWindow.document.querySelector('.print')?.addEventListener('click', () => invoiceWindow.print());
    setTimeout(() => invoiceWindow.print(), 300);
  } catch (error) {
    console.error('Unable to prepare order invoice', error);
    invoiceWindow.document.body.textContent = tr('invoiceFailed');
  }
}
function showStats(all) {
  let box = document.querySelector('#staffStats');
  if (!box) { box = document.createElement('div'); box.id = 'staffStats'; box.className = 'stats'; document.querySelector('#staffOrderList').parentElement.before(box); }
  const today = new Date().toDateString(), tally = {};
  const todays = all.filter(o => o.createdAt?.toDate?.().toDateString() === today);
  const revenue = all.filter(o => o.status === 'delivered' && toDate(o.deliveredAt)?.toDateString() === today).reduce((sum, o) => sum + Number(o.totalUsd || 0), 0);
  const late = all.filter(o => o.status === 'placed' && Date.now() - (o.createdAt?.toMillis?.() || Date.now()) > 864e5).length;
  all.filter(o => o.status !== 'cancelled').forEach(o => (o.items || []).forEach(i => { tally[i.title] = (tally[i.title] || 0) + i.quantity; }));
  const top = Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([n, q]) => `${n} (${q})`).join(', ') || '—';
  box.replaceChildren(...[[tr('statToday'), todays.length], [tr('statRevenue'), `$${revenue.toFixed(2)}`], [tr('statLate'), late], [tr('statTop'), top]].map(([k, v]) => { const el = document.createElement('div'); const label = document.createElement('p'); label.textContent = k; const value = document.createElement('strong'); value.textContent = v; el.append(label, value); return el; }));
}
async function loadStaffOrders() {
  if (staffRole !== 'delivery') {
    try {
      const staff = await getDocs(collection(db, 'staff'));
      workers = staff.docs.filter(w => String(w.data().role || '').trim().toLowerCase() === 'delivery')
        .map(w => ({ id: w.id, email: w.data().email || '', name: w.data().name || w.id }));
    } catch (error) { console.error('Could not load delivery workers', error); workers = []; }
  }
  const list = document.querySelector('#staffOrderList'), count = document.querySelector('#staffOrderCount');
  const base = collectionGroup(db, 'orders');
  const terminal = staffRole === 'delivery' ? ['delivered', 'cancelled', 'delivery_failed'] : ['delivered', 'cancelled'];
  const renderOrders = result => {
    if (staffRole !== 'delivery') {
      showStats(result.docs.map(s => s.data()));
      // One-time repair for legacy packed orders that have no assignedTo field (drivers' queries cannot see them).
      result.docs.forEach(s => { const d = s.data(); if (d.status === 'packed' && !('assignedTo' in d) && !migrated.has(s.ref.path)) { migrated.add(s.ref.path); updateDoc(s.ref, { assignedTo: null, updatedAt: serverTimestamp() }).catch(error => console.warn('Could not migrate legacy order', error)); } });
    }
    const orders = result.docs.filter(s => !terminal.includes(s.data().status)).sort((a, b) => (b.data().createdAt?.toMillis?.() || 0) - (a.data().createdAt?.toMillis?.() || 0));
    count.textContent = `${orders.length} ${tr(orders.length === 1 ? 'order_one' : 'order_other')}`; list.replaceChildren();
    if (!orders.length) { const empty = document.createElement('p'); empty.className = 'history-empty'; empty.textContent = tr('noActive'); list.append(empty); return; }
    orders.forEach(s => list.append(createOrderCard(s.id, s.data(), true, s.ref)));
  };
  availableUnsub?.(); availableUnsub = null;
  if (staffRole === 'delivery') {
    let assigned = new Map(), available = new Map(), availableLegacy = new Map();
    const renderCombined = () => renderOrders({ docs: [...assigned.values(), ...available.values(), ...availableLegacy.values()] });
    listen(query(base, where('assignedTo', '==', signedInUser.uid)), result => {
      assigned = new Map(result.docs.map(s => [s.ref.path, s])); renderCombined();
    });
    availableUnsub = onSnapshot(query(base, where('status', '==', 'packed'), where('assignedTo', '==', null)), result => {
      available = new Map(result.docs.map(s => [s.ref.path, s])); renderCombined();
    }, error => console.error('Available orders listener failed', error));
    const legacyAvailableUnsub = onSnapshot(query(base, where('status', '==', 'packed'), where('assignedTo', '==', '')), result => {
      availableLegacy = new Map(result.docs.map(s => [s.ref.path, s])); renderCombined();
    }, error => console.error('Legacy available orders listener failed', error));
    const stopAvailableListeners = availableUnsub;
    availableUnsub = () => { stopAvailableListeners?.(); legacyAvailableUnsub(); };
  } else listen(base, renderOrders);
}
async function acceptTask(ref) {
  try {
    await runTransaction(db, async tx => {
      const latest = await tx.get(ref);
      if (!latest.exists()) throw new Error('This task is no longer available.');
      const data = latest.data();
      if (data.status !== 'packed' || (data.assignedTo != null && data.assignedTo !== '')) throw new Error('This task is no longer available.');
      tx.update(ref, { assignedTo: signedInUser.uid, updatedAt: serverTimestamp() });
    });
  } catch (error) {
    console.error('Unable to accept delivery task', error);
    alert(error.message === 'This task is no longer available.' ? tr('taken') : tr('takeFail'));
  }
}
async function makeTaskAvailable(ref, button) {
  const originalText = button.textContent;
  button.disabled = true;
  button.textContent = isAr() ? 'جارٍ الإتاحة…' : 'Making available…';
  try {
    await runTransaction(db, async tx => {
      const latest = await tx.get(ref);
      if (!latest.exists() || latest.data().status !== 'packed') throw new Error('Only packed orders can be opened for delivery.');
      const assignedTo = latest.data().assignedTo;
      if (assignedTo && assignedTo !== '') throw new Error('This task is already assigned. Reassign it first.');
      tx.update(ref, { assignedTo: null, updatedAt: serverTimestamp() });
    });
    button.textContent = isAr() ? 'متاح لعُمّال التوصيل' : 'Available to drivers';
  } catch (error) {
    console.error('Unable to open delivery task', error);
    alert(error.message === 'Only packed orders can be opened for delivery.' || error.message === 'This task is already assigned. Reassign it first.'
      ? error.message
      : 'Could not make this task available. Deploy the latest Firestore rules, then try again.');
    button.disabled = false;
    button.textContent = originalText;
  }
}
function renderInventory(products) {
  catalogProducts = products;
  const list = document.querySelector('#inventoryList');
  const count = document.querySelector('#inventoryCount');
  const units = products.reduce((sum, product) => sum + Number(product.stock || 0), 0);
  count.textContent = tr('invSummary', { p: products.length, u: units });
  list.replaceChildren();
  products.forEach(product => {
    const card = document.createElement('article'); card.className = 'inventory-card';
    const info = document.createElement('div'); info.className = 'inventory-product-info';
    const image = document.createElement('img'); image.src = product.image || ''; image.alt = ''; image.loading = 'lazy';
    const text = document.createElement('div');
    const title = document.createElement('h3'); title.textContent = product.title || product.name || `Product ${product.id}`;
    const stock = document.createElement('p'); stock.className = 'inventory-stock'; stock.textContent = tr('unitsNow', { n: Number(product.stock || 0) });
    text.append(title, stock);
    if (product.saved === false) { const note = document.createElement('p'); note.className = 'inventory-stock'; note.textContent = tr('notSaved'); text.append(note); }
    info.append(image, text);
    const fields = document.createElement('div'); fields.className = 'inventory-fields';
    const priceLabel = document.createElement('label'); priceLabel.textContent = tr('price');
    const priceInput = document.createElement('input'); priceInput.type = 'number'; priceInput.min = '0'; priceInput.step = '0.01'; priceInput.value = Number(product.price || 0).toFixed(2); priceLabel.append(priceInput);
    const stockLabel = document.createElement('label'); stockLabel.textContent = tr('stockQty');
    const stockInput = document.createElement('input'); stockInput.type = 'number'; stockInput.min = '0'; stockInput.step = '1'; stockInput.value = String(Number(product.stock || 0)); stockLabel.append(stockInput);
    const save = document.createElement('button'); save.type = 'button'; save.className = 'small-action'; save.textContent = tr('save');
    const message = document.createElement('span'); message.className = 'inventory-save-message'; message.setAttribute('role', 'status');
    save.addEventListener('click', async () => {
      const price = Number(priceInput.value), stockValue = Number(stockInput.value);
      if (!Number.isFinite(price) || price < 0 || !Number.isInteger(stockValue) || stockValue < 0) { message.textContent = tr('invalid'); return; }
      save.disabled = true; message.textContent = tr('savingNow');
      try {
        await setDoc(doc(db, 'products', String(product.id)), { id: String(product.id), title: product.title || product.name || '', category: product.category || '', image: product.image || '', description: product.description || '', price, stock: stockValue, updatedAt: serverTimestamp(), updatedBy: signedInUser.uid }, { merge: true });
        product.price = price; product.stock = stockValue; product.saved = true;
        stock.textContent = tr('unitsNow', { n: stockValue });
        count.textContent = tr('invSummary', { p: products.length, u: products.reduce((sum, item) => sum + Number(item.stock || 0), 0) });
        window.dispatchEvent(new CustomEvent('marketly:inventory-updated', { detail: { id: product.id, price, stock: stockValue } }));
        message.textContent = tr('saved');
      } catch (error) { console.error('Unable to save product inventory', error); message.textContent = tr('saveFailed'); }
      finally { save.disabled = false; }
    });
    fields.append(priceLabel, stockLabel, save, message); card.append(info, fields); list.append(card);
  });
}
async function updateOrder(ref, order, changes, stock = 0) {
  try {
    await runTransaction(db, async tx => {
      const items = order.items || [];
      const snaps = stock ? await Promise.all(items.map(i => tx.get(doc(db, 'products', i.productId)))) : [];
      if (stock < 0) snaps.forEach((p, n) => {
        const i = items[n];
        if (!p.exists() || Number(p.data().stock) < i.quantity) throw new Error(`Not enough stock: ${i.title}`);
        if (Math.abs(Number(p.data().price) - Number(i.unitPriceUsd)) > 0.01) throw new Error(`Price mismatch: ${i.title}`);
      });
      snaps.forEach((p, n) => tx.update(p.ref, { stock: increment(stock * items[n].quantity) }));
      tx.update(ref, { ...changes, statusHistory: [...(order.statusHistory || []), { status: changes.status, at: new Date().toISOString(), by: signedInUser.uid }], updatedAt: serverTimestamp() });
    });
    return true;
  } catch (error) {
    console.error('Unable to update order', error);
    const reason = /^(Not enough|Price)/.test(error.message) ? error.message : `${error.code || 'error'}: ${error.message || 'Check the staff role and Firestore rules.'}`;
    alert(`${tr('cannotUpdate')} ${reason}`);
    return false;
  }
}
async function cancelOrder(uid, id, order) {
  if (!confirm(tr('cancelConfirm'))) return;
  try {
    const orderRef = doc(db, 'users', uid, 'orders', id);
    await runTransaction(db, async transaction => {
      const latest = await transaction.get(orderRef);
      if (!latest.exists() || latest.data().status !== 'placed') throw new Error('This order can no longer be cancelled.');
      const current = latest.data();
      if (current.inventoryReserved === true) {
        const items = current.items || [];
        const productRefs = items.map(item => doc(db, 'products', item.productId));
        const products = await Promise.all(productRefs.map(ref => transaction.get(ref)));
        products.forEach((snapshot, index) => {
          if (!snapshot.exists()) throw new Error('A product is no longer available.');
          transaction.update(snapshot.ref, {
            stock: snapshot.data().stock + items[index].quantity,
            lastReservationOrderId: id
          });
        });
      }
      transaction.update(orderRef, {
        status: 'cancelled',
        statusHistory: [...(current.statusHistory || []), { status: 'cancelled', at: new Date().toISOString(), by: uid }],
        updatedAt: serverTimestamp()
      });
    });
  }
  catch (error) { console.error('Unable to cancel order', error); alert(tr('cancelFailed')); }
}
function showView(view) {
  const dashboardActive = view === 'dashboard';
  dashboardView.classList.toggle('hidden', !dashboardActive); staffView.classList.add('hidden');
  document.querySelectorAll('.shop-app > .welcome, .shop-app > .promo-media, .shop-app > .catalog-section, .shop-app > footer').forEach(node => node.classList.toggle('hidden', dashboardActive));
  document.querySelector('#dashboardTab').classList.toggle('active', dashboardActive); document.querySelector('#shopTab').classList.toggle('active', !dashboardActive); storeView.classList.toggle('hidden', dashboardActive);
}
document.querySelector('#dashboardTab').addEventListener('click', () => showView('dashboard'));
document.querySelector('#shopTab').addEventListener('click', () => showView('shop'));
document.querySelector('#browseShopButton').addEventListener('click', () => showView('shop'));
document.querySelector('#logoutButton').addEventListener('click', async () => { const { signOut } = await import('https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js'); unsub?.(); availableUnsub?.(); await signOut(auth); signedInUser = null; staffRole = ''; contactCache.clear(); });
document.querySelector('#staffLogout').addEventListener('click', () => document.querySelector('#logoutButton').click());
document.querySelector('#completedOrdersButton').addEventListener('click', () => document.querySelector('#completedOrdersModal').classList.remove('hidden'));
document.querySelectorAll('[data-completed-close="true"]').forEach(element => element.addEventListener('click', () => document.querySelector('#completedOrdersModal').classList.add('hidden')));
window.addEventListener('marketly:cart-count', event => { document.querySelector('#dashboardCartCount').textContent = String(event.detail); });
window.addEventListener('marketly:order-placed', event => { if (staffRole === 'customer') loadOrderHistory(signedInUser.uid); });
window.addEventListener('marketly:products-loaded', event => {
  catalogProducts = event.detail;
  if (staffRole !== 'employee' && staffRole !== 'admin') return;
  renderInventory(catalogProducts);
  const head = document.querySelector('#inventoryPanel .history-heading');
  if (head && !head.querySelector('.bulk-stock')) {
    const b = btn(tr('bulk'), async () => {
      b.disabled = true;
      const empty = catalogProducts.filter(p => !Number(p.stock));
      try {
        const batch = writeBatch(db); // all-or-nothing instead of stopping half way
        empty.forEach(p => batch.set(doc(db, 'products', String(p.id)), { id: String(p.id), title: p.title || p.name || '', category: p.category || '', image: p.image || '', description: p.description || '', price: Number(p.price), stock: 10, updatedAt: serverTimestamp(), updatedBy: signedInUser.uid }, { merge: true }));
        await batch.commit();
        empty.forEach(p => { p.stock = 10; p.saved = true; });
      } catch (error) { console.error('Bulk stock failed', error); alert(tr('saveFailed')); }
      renderInventory(catalogProducts); b.disabled = false;
    });
    b.classList.add('bulk-stock'); head.append(b);
  }
});

async function fillContact(detail, ref, order) {
  if (staffRole === 'delivery' && order.assignedTo !== signedInUser.uid) { detail.textContent = tr('contactHidden'); return; }
  detail.textContent = tr('contactLoading');
  try {
    let contact = contactCache.get(ref.path);
    if (!contact) {
      const snapshot = await getDoc(doc(ref, 'private', 'contact'));
      contact = snapshot.exists() ? snapshot.data() : { customerName: order.customerName, phone: order.phone, address: order.address }; // legacy orders kept contact data on the order itself
      contactCache.set(ref.path, contact);
    }
    detail.textContent = `${contact.customerName || tr('role_customer')} · ${contact.phone || tr('noPhone')} · ${contact.address || tr('noAddress')}`;
  } catch (error) { console.warn('Could not load contact details', error); detail.textContent = tr('contactFailed'); }
}
window.addEventListener('marketly:language-changed', () => {
  if (!signedInUser) return;
  document.querySelector('#accountName').textContent = `${signedInUser.email || ''} · ${roleLabel(staffRole)}`;
  if (staffRole === 'customer') { loadOrderHistory(signedInUser.uid); return; }
  setStaffHeadings(); loadStaffOrders();
  if (staffRole !== 'delivery' && catalogProducts.length) renderInventory(catalogProducts);
});

function deletionText(order) {
  if (!TERMINAL_STATUSES.includes(order.status)) return '';
  const ms = order.expiresAt?.toMillis?.() ?? (order.createdAt?.toMillis ? order.createdAt.toMillis() + RETENTION_SECONDS * 1000 : null);
  return ms ? tr('deletesOn', { date: new Date(ms).toLocaleDateString(isAr() ? 'ar' : undefined) }) : '';
}
function setRetentionNotes() {
  [['#dashboardView .order-history .history-heading', 'main'], ['#completedOrdersModal .history-heading', 'modal']].forEach(([selector, key]) => {
    const heading = document.querySelector(selector); if (!heading) return;
    let note = document.querySelector(`[data-retention="${key}"]`);
    if (!note) { note = document.createElement('p'); note.className = 'retention-note'; note.dataset.retention = key; note.setAttribute('role', 'note'); heading.after(note); }
    note.textContent = tr('retention');
  });
}
