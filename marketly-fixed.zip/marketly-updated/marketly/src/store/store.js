import { auth, db } from '../firebase/firebase.js';
import { collection, doc, getDocs, runTransaction, serverTimestamp, Timestamp } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';
import { formatMoney, getCurrency, getRate } from './currency.js';
import { tr } from '../ui/i18n.js';
const fallbackProducts = [
  { id: 'local-1', title: 'Pebble speaker', category: 'electronics', price: 89, image: 'https://fakestoreapi.com/img/81QpkIctqPL._AC_SX679_.jpg', description: 'A compact wireless speaker with warm sound, tactile controls, and an all-day battery.', color: '#dce7e1' },
  { id: 'local-2', title: 'Mori desk lamp', category: 'home', price: 64, image: 'https://images.unsplash.com/photo-1517705008128-361805f42e86?auto=format&fit=crop&w=900&q=80', description: 'Soft, directional light for late-night ideas and slow Sunday mornings.', color: '#e8ddca' },
  { id: 'local-3', title: 'Everyday tote', category: "women's clothing", price: 42, image: 'https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_.jpg', description: 'A generous recycled-canvas carryall with an inside pocket for little essentials.', color: '#e5d9e4' },
  { id: 'local-4', title: 'Cloud mug', category: 'home', price: 28, image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=900&q=80', description: 'Hand-finished stoneware that makes your first coffee feel like a ritual.', color: '#d9e5f0' },
  { id: 'local-5', title: 'Mono headphones', category: 'electronics', price: 120, image: 'https://fakestoreapi.com/img/71-3HjGNDUL._AC_SY879._SX._UX._SY._UY_.jpg', description: 'Crisp, balanced audio in a lightweight silhouette built for long listening.', color: '#dedede' },
  { id: 'local-6', title: 'Field notes set', category: "men's clothing", price: 18, image: 'https://fakestoreapi.com/img/71YXzeOuslL._AC_UY879_.jpg', description: 'Three pocket notebooks for lists, sketches, plans, and everything in between.', color: '#e8e0c5' },
  { id: 'local-7', title: 'Arc vase', category: 'home', price: 55, image: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?auto=format&fit=crop&w=900&q=80', description: 'A sculptural ceramic vase that brings a quiet shape to any shelf.', color: '#dce4d6' },
  { id: 'local-8', title: 'Lumen watch', category: 'jewelery', price: 96, image: 'https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_.jpg', description: 'A minimal everyday watch with a brushed steel case and soft leather strap.', color: '#e9d7cd' }
];

const translations = {
  en: { language: 'Language', cart: 'Cart', logout: 'Log out', weekly: 'THE WEEKLY EDIT', hero: 'Small upgrades.<br><em>Big difference.</em>', heroDescription: 'Useful objects, beautiful details, and things you didn’t know you needed.', arrivals: 'NEW<br>ARRIVALS', shop: 'SHOP THE EDIT', popular: 'Popular right now', all: 'All', home: 'Home', tech: 'Tech', style: 'Style', electronics: 'Electronics', jewelery: 'Jewelery', mensClothing: "Men's clothing", womensClothing: "Women's clothing", tagline: 'Made for curious people.', selection: 'YOUR SELECTION', yourCart: 'Your cart', subtotal: 'Subtotal', delivery: 'Delivery fee', total: 'Total', checkout: 'Checkout', empty: 'Your cart is empty.', remove: 'Remove' },
  fr: { language: 'Langue', cart: 'Panier', logout: 'Se déconnecter', weekly: 'LA SÉLECTION DE LA SEMAINE', hero: 'Petites améliorations.<br><em>Grande différence.</em>', heroDescription: 'Des objets utiles et de beaux détails, pour votre quotidien.', arrivals: 'NOUVEAUTÉS', shop: 'LA SÉLECTION', popular: 'Les plus populaires', all: 'Tous', home: 'Maison', tech: 'Tech', style: 'Style', electronics: 'Électronique', jewelery: 'Bijoux', mensClothing: 'Vêtements hommes', womensClothing: 'Vêtements femmes', tagline: 'Pour les esprits curieux.', selection: 'VOTRE SÉLECTION', yourCart: 'Votre panier', subtotal: 'Sous-total', delivery: 'Livraison', total: 'Total', checkout: 'Commander', empty: 'Votre panier est vide.', remove: 'Supprimer' },
  ar: { language: 'اللغة', cart: 'السلة', logout: 'تسجيل الخروج', weekly: 'اختيارات هذا الأسبوع', hero: 'تغييرات صغيرة.<br><em>فرق كبير.</em>', heroDescription: 'أشياء مفيدة وتفاصيل جميلة تناسب حياتك اليومية.', arrivals: 'وصل حديثاً', shop: 'تسوق الاختيارات', popular: 'الأكثر طلباً الآن', all: 'الكل', home: 'المنزل', tech: 'التقنية', style: 'الأناقة', electronics: 'الإلكترونيات', jewelery: 'مجوهرات', mensClothing: 'ملابس الرجال', womensClothing: 'ملابس النساء', tagline: 'مصمم للفضوليين.', selection: 'اختياراتك', yourCart: 'سلة التسوق', subtotal: 'المجموع الفرعي', delivery: 'رسوم التوصيل', total: 'الإجمالي', checkout: 'إتمام الشراء', empty: 'السلة فارغة.', remove: 'حذف' },
  es: { language: 'Idioma', cart: 'Carrito', logout: 'Cerrar sesión', weekly: 'LA SELECCIÓN DE LA SEMANA', hero: 'Pequeñas mejoras.<br><em>Gran diferencia.</em>', heroDescription: 'Objetos útiles, detalles bonitos y cosas que no sabías que necesitabas.', arrivals: 'NOVEDADES', shop: 'LA SELECCIÓN', popular: 'Lo más popular', all: 'Todo', home: 'Hogar', tech: 'Tecnología', style: 'Estilo', electronics: 'Electrónica', jewelery: 'Joyería', mensClothing: 'Ropa de hombre', womensClothing: 'Ropa de mujer', tagline: 'Para personas curiosas.', selection: 'TU SELECCIÓN', yourCart: 'Tu carrito', subtotal: 'Subtotal', delivery: 'Gastos de envío', total: 'Total', checkout: 'Finalizar compra', empty: 'Tu carrito está vacío.', remove: 'Eliminar' }
};

const authScreen = document.querySelector('#authScreen');
const shopApp = document.querySelector('#shopApp');
const authForm = document.querySelector('#authForm');
const authMessage = document.querySelector('#authMessage');
const categoryColors = {
  electronics: '#dfe7ff',
  jewelery: '#f5e3d3',
  "men's clothing": '#dfe9d9',
  "women's clothing": '#f0e1ec',
  home: '#e3dcc7',
  tech: '#dce7e1',
  style: '#e5d9e4'
};
let isSignUp = false;
let activeCategory = 'All';
let currentLanguage = localStorage.getItem('marketlyLanguage') || 'en';
let cart = [];
let products = [];
const DELIVERY_FEE_USD = 5;
const MAX_LINES = 8, MAX_QTY = 20; // must match firestore.rules
let apiCategories = ['electronics', 'jewelery', "men's clothing", "women's clothing"];

function text() { return translations[currentLanguage]; }
function esc(value = '') { return String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }
function safeUrl(url = '') { return /^https?:\/\//i.test(String(url)) ? esc(url) : ''; }
function normalizeCategory(category = '') { return String(category).trim().toLowerCase(); }
function getProductColor(category = '') { const key = normalizeCategory(category); return categoryColors[key] || '#e8f0eb'; }
function localizeCategory(category = '') { const normalized = normalizeCategory(category); if (normalized === 'electronics') return text().electronics || 'Electronics'; if (normalized === 'jewelery') return text().jewelery || 'Jewelery'; if (normalized === "men's clothing") return text().mensClothing || "Men's clothing"; if (normalized === "women's clothing") return text().womensClothing || "Women's clothing"; return text()[normalized] || category; }
function buildFilters(categories = apiCategories) {
  const filterOptions = ['All', ...categories];
  const filterContainer = document.querySelector('#filters');
  filterContainer.innerHTML = filterOptions.map(category => {
    const isActive = category === activeCategory;
    const label = category === 'All' ? text().all : localizeCategory(category);
    return `<button class="${isActive ? 'active' : ''}" data-category="${esc(category)}">${esc(label)}</button>`;
  }).join('');
  filterContainer.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', () => {
      activeCategory = button.dataset.category;
      filterContainer.querySelectorAll('button').forEach(item => item.classList.toggle('active', item === button));
      renderProducts();
    });
  });
}
function stockLabel(product) { const n = Number(product.stock || 0); return n <= 0 ? tr('outOfStock') : n <= 5 ? tr('lowStock', { n }) : tr('inStock', { n }); }
function sortProducts(list) { const mode = document.querySelector('#sortSelect').value; return mode === 'low' ? [...list].sort((a, b) => a.price - b.price) : mode === 'high' ? [...list].sort((a, b) => b.price - a.price) : list; }
function renderProducts() {
  const query = document.querySelector('#searchInput').value.toLowerCase();
  const visible = sortProducts(products.filter(product => {
    const matchCategory = activeCategory === 'All' || normalizeCategory(product.category) === normalizeCategory(activeCategory);
    const productTitle = (product.title || product.name || '').toLowerCase();
    return matchCategory && productTitle.includes(query);
  }));
  document.querySelector('#productGrid').innerHTML = visible.length ? visible.map(product => `<article class="product-card${Number(product.stock || 0) <= 0 ? ' sold-out' : ''}" data-id="${esc(product.id)}"><div class="product-image" style="background:${getProductColor(product.category)}"><img src="${safeUrl(product.image)}" alt="${esc(product.title || product.name)}"></div><h3>${esc(product.title || product.name)}</h3><div class="product-meta"><span>${esc(localizeCategory(product.category))}</span><span class="stock-count${Number(product.stock || 0) <= 0 ? ' out' : Number(product.stock) <= 5 ? ' low' : ''}">${esc(stockLabel(product))}</span><strong>${formatMoney(Number(product.price))}</strong></div></article>`).join('') : `<p class="empty-cart">${esc(tr('noMatch'))}</p>`;
  document.querySelectorAll('.product-card').forEach(card => card.addEventListener('click', () => {
    const matchingProduct = products.find(product => String(product.id) === card.dataset.id);
    openModal(matchingProduct);
  }));
}
function openModal(product) {
  if (!product) return;
  const visual = document.querySelector('#modalVisual');
  visual.innerHTML = `<img src="${safeUrl(product.image)}" alt="${esc(product.title || product.name)}">`;
  visual.style.background = getProductColor(product.category);
  document.querySelector('#modalCategory').textContent = localizeCategory(product.category);
  document.querySelector('#modalTitle').textContent = product.title || product.name;
  document.querySelector('#modalDescription').textContent = product.description;
  document.querySelector('#modalPrice').textContent = `${formatMoney(Number(product.price))}`;
  const productModal = document.querySelector('#productModal');
  productModal.dataset.productId = String(product.id);
  productModal.classList.remove('hidden');
}
function addToCart(product) {
  if (!product) return;
  const item = cart.find(entry => String(entry.product.id) === String(product.id));
  const inCart = item?.quantity || 0;
  if (Number(product.stock || 0) <= inCart) { alert(tr('stockAlert')); return; }
  if (!item && cart.length >= MAX_LINES) { alert(tr('cartLimit')); return; }
  if (inCart >= MAX_QTY) { alert(tr('lineLimit')); return; }
  if (item) item.quantity += 1; else cart.push({ product, quantity: 1 });
  updateCartCount(); renderCart();
  document.querySelector('#productModal').classList.add('hidden');
}
function updateCartCount() { const count = cart.reduce((total, item) => total + item.quantity, 0); document.querySelector('#cartCount').textContent = count; window.dispatchEvent(new CustomEvent('marketly:cart-count', { detail: count })); }
function getCartTotals() {
  const subtotalUsd = cart.reduce((sum, item) => sum + Number(item.product.price) * item.quantity, 0);
  const deliveryFeeUsd = cart.length ? DELIVERY_FEE_USD : 0;
  return { subtotalUsd, deliveryFeeUsd, totalUsd: subtotalUsd + deliveryFeeUsd };
}
function updateCartSummary() {
  const totals = getCartTotals();
  document.querySelector('#cartSubtotal').textContent = formatMoney(totals.subtotalUsd);
  document.querySelector('#cartDelivery').textContent = formatMoney(totals.deliveryFeeUsd);
  document.querySelector('#cartTotal').textContent = formatMoney(totals.totalUsd);
}
function updateCheckoutSummary() {
  const totals = getCartTotals();
  document.querySelector('#checkoutDelivery').textContent = formatMoney(totals.deliveryFeeUsd);
  document.querySelector('#checkoutTotal').textContent = formatMoney(totals.totalUsd);
}
function renderCart() {
  const container = document.querySelector('#cartItems');
  if (!cart.length) { container.innerHTML = `<p class="empty-cart">${text().empty}</p><button class="small-action" id="emptyCartShop" type="button">${esc(tr('backToShop'))}</button>`; document.querySelector('#emptyCartShop').addEventListener('click', () => document.querySelector('#cartModal').classList.add('hidden')); updateCartSummary(); return; }
  container.innerHTML = cart.map((item, index) => `<div class="cart-item"><div class="cart-item-visual" style="background:${getProductColor(item.product.category)}"><img src="${safeUrl(item.product.image)}" alt="${esc(item.product.title || item.product.name)}" /></div><div class="cart-item-copy"><strong>${esc(item.product.title || item.product.name)}</strong><span>${formatMoney(Number(item.product.price))}</span><div class="quantity-controls"><button data-cart-action="decrease" data-index="${index}" aria-label="Decrease quantity">−</button><b>${item.quantity}</b><button data-cart-action="increase" data-index="${index}" aria-label="Increase quantity">+</button><button class="remove-item" data-cart-action="remove" data-index="${index}">${text().remove}</button></div></div></div>`).join('');
  updateCartSummary();
  container.querySelectorAll('[data-cart-action]').forEach(button => button.addEventListener('click', () => changeCart(button.dataset.cartAction, Number(button.dataset.index))));
}
function changeCart(action, index) { const item = cart[index]; if (!item) return; if (action === 'increase') { if (item.quantity >= Math.min(MAX_QTY, Number(item.product.stock || 0))) return; item.quantity += 1; } if (action === 'decrease') item.quantity -= 1; if (action === 'remove' || item.quantity < 1) cart.splice(index, 1); updateCartCount(); renderCart(); }
function openCart() { renderCart(); document.querySelector('#cartModal').classList.remove('hidden'); }
function setLanguage(language) {
  currentLanguage = language; localStorage.setItem('marketlyLanguage', language); const value = text();
  document.documentElement.lang = language; document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  document.querySelector('#languageLabel').textContent = value.language; document.querySelector('#cartLabel').textContent = value.cart; document.querySelector('#logoutButton').textContent = value.logout; document.querySelector('#weeklyEyebrow').textContent = value.weekly; document.querySelector('#heroTitle').innerHTML = value.hero; document.querySelector('#heroDescription').textContent = value.heroDescription; document.querySelector('#arrivalLabel').innerHTML = value.arrivals; document.querySelector('#shopEyebrow').textContent = value.shop; document.querySelector('#popularTitle').textContent = value.popular; document.querySelector('#footerTagline').textContent = value.tagline; document.querySelector('#cartEyebrow').textContent = value.selection; document.querySelector('#cartTitle').textContent = value.yourCart; document.querySelector('#subtotalLabel').textContent = value.subtotal; document.querySelector('#deliveryLabel').textContent = value.delivery; document.querySelector('#checkoutDeliveryLabel').textContent = value.delivery; document.querySelector('#totalLabel').textContent = value.total; document.querySelector('#checkoutTotalLabel').textContent = value.total; document.querySelector('#checkoutLabel').textContent = value.checkout; document.querySelector('#languageSelect').value = language;
  const sort = document.querySelector('#sortSelect'); [['', 'sortDefault'], ['low', 'sortLow'], ['high', 'sortHigh']].forEach(([v, k], i) => { sort.options[i].textContent = tr(k); });
  document.querySelector('#cartCodNote').textContent = tr('codCartNote');
  buildFilters(apiCategories);
  renderProducts();
  renderCart();
  window.dispatchEvent(new CustomEvent('marketly:language-changed'));
}
async function fetchStoreData() {
  // Firestore `products` is the source of truth. The public demo API only supplies starter items for employees to import.
  let seeds = fallbackProducts;
  try {
    const [productsResponse, categoryResponse, jeweleryResponse] = await Promise.all([
      fetch('https://fakestoreapi.com/products'),
      fetch('https://fakestoreapi.com/products/categories'),
      fetch('https://fakestoreapi.com/products/category/jewelery')
    ]);
    if (!productsResponse.ok || !categoryResponse.ok || !jeweleryResponse.ok) throw new Error('Store API unavailable');
    const fetchedProducts = await productsResponse.json();
    const fetchedCategories = await categoryResponse.json();
    const fetchedJeweleryProducts = await jeweleryResponse.json();
    if (Array.isArray(fetchedProducts) && fetchedProducts.length) seeds = fetchedProducts;
    if (Array.isArray(fetchedCategories) && fetchedCategories.length) apiCategories = fetchedCategories;
    if (Array.isArray(fetchedJeweleryProducts) && fetchedJeweleryProducts.length) {
      seeds = seeds.filter(product => normalizeCategory(product.category) !== 'jewelery').concat(fetchedJeweleryProducts);
    }
  } catch (error) {
    console.error('Using fallback products:', error);
    apiCategories = ['electronics', 'jewelery', "men's clothing", "women's clothing"];
  }
  let saved = [];
  try {
    const inventory = await getDocs(collection(db, 'products'));
    saved = inventory.docs.map(snapshot => ({ ...snapshot.data(), id: snapshot.id }))
      .filter(product => product.title && Number.isFinite(product.price))
      .map(product => ({ ...product, price: Number(product.price), stock: Number.isInteger(product.stock) ? product.stock : 0, saved: true }));
  } catch (error) { console.warn('Inventory could not be loaded; showing catalog defaults.', error); }
  const savedIds = new Set(saved.map(product => String(product.id)));
  const seedList = seeds.map(product => ({ ...product, id: String(product.id), price: Number(product.price), stock: 0, saved: false }));
  products = saved.length ? saved : seedList;
  if (saved.length) apiCategories = [...new Set(saved.map(product => product.category).filter(Boolean))];
  buildFilters(apiCategories);
  renderProducts();
  renderCart();
  window.dispatchEvent(new CustomEvent('marketly:products-loaded', { detail: [...saved, ...seedList.filter(product => !savedIds.has(product.id))] }));
}

document.querySelector('#searchInput').addEventListener('input', renderProducts); document.querySelector('#sortSelect').addEventListener('change', renderProducts); document.querySelector('#cartButton').addEventListener('click', openCart); document.querySelector('#addButton').addEventListener('click', () => { const activeProductId = String(document.querySelector('#productModal').dataset.productId); addToCart(products.find(product => String(product.id) === activeProductId)); }); document.querySelectorAll('[data-close="true"]').forEach(element => element.addEventListener('click', () => document.querySelector('#productModal').classList.add('hidden'))); document.querySelectorAll('[data-cart-close="true"]').forEach(element => element.addEventListener('click', () => document.querySelector('#cartModal').classList.add('hidden'))); document.querySelector('#checkoutButton').addEventListener('click', () => { if (!cart.length) return; updateCheckoutSummary(); document.querySelector('#checkoutMessage').textContent = ''; document.querySelector('#checkoutModal').classList.remove('hidden'); }); document.querySelectorAll('[data-checkout-close="true"]').forEach(element => element.addEventListener('click', () => document.querySelector('#checkoutModal').classList.add('hidden'))); document.querySelector('#checkoutForm').addEventListener('submit', placeOrder); document.querySelector('#languageSelect').addEventListener('change', event => setLanguage(event.target.value));
setLanguage(currentLanguage); updateCartCount(); fetchStoreData();
window.addEventListener('marketly:currency-changed', () => { renderProducts(); renderCart(); });
window.addEventListener('marketly:inventory-updated', event => {
  const product = products.find(item => String(item.id) === String(event.detail.id));
  if (!product) return;
  product.price = event.detail.price;
  product.stock = event.detail.stock;
  renderProducts();
  renderCart();
});

async function placeOrder(event) {
  event.preventDefault();
  if (!cart.length || !auth.currentUser) return;
  const button = document.querySelector('#checkoutButton');
  button.disabled = true;
  const submitButton = document.querySelector('#checkoutForm button[type="submit"]');
  submitButton.disabled = true;
  try {
    const totals = getCartTotals();
    const expiresAt = Timestamp.fromMillis(Date.now() + 30 * 24 * 60 * 60 * 1000);
    const order = {
      uid: auth.currentUser.uid,
      items: cart.map(({ product, quantity }) => ({ productId: String(product.id), title: String(product.title || product.name || '').slice(0, 200), image: /^https?:\/\//i.test(product.image || '') ? String(product.image).slice(0, 500) : '', quantity, unitPriceUsd: Number(product.price) })),
      subtotalUsd: totals.subtotalUsd,
      deliveryFeeUsd: totals.deliveryFeeUsd,
      totalUsd: totals.totalUsd,
      currency: getCurrency(),
      exchangeRate: getRate(),
      total: totals.totalUsd * getRate(),
      inventoryReserved: true,
      paymentMethod: 'cod',
      paymentStatus: 'pending',
      assignedTo: null,
      status: 'placed',
      statusHistory: [{ status: 'placed', at: new Date().toISOString() }],
      createdAt: serverTimestamp(),
      expiresAt
    };
    // Contact details are stored in a private subdocument so unassigned orders do not expose them to every driver.
    const contact = {
      phone: document.querySelector('#deliveryPhone').value.trim().slice(0, 20),
      address: document.querySelector('#deliveryAddress').value.trim().slice(0, 300),
      customerName: (auth.currentUser.displayName || '').slice(0, 100),
      customerEmail: (auth.currentUser.email || '').slice(0, 200),
      expiresAt
    };
    const orderRef = doc(collection(db, 'users', auth.currentUser.uid, 'orders'));
    await runTransaction(db, async transaction => {
      const productsToCheck = cart.map(({ product, quantity }) => ({
        ref: doc(db, 'products', String(product.id)), product, quantity
      }));
      const snapshots = await Promise.all(productsToCheck.map(item => transaction.get(item.ref)));
      for (let i = 0; i < productsToCheck.length; i++) {
        const item = productsToCheck[i], snapshot = snapshots[i];
        if (!snapshot.exists()) throw new Error('product-missing');
        const data = snapshot.data();
        if (Number(data.price) !== Number(item.product.price)) throw new Error('price-changed');
        if (!Number.isInteger(data.stock) || data.stock < item.quantity) throw new Error('stock-unavailable');
      }
      // Reserve stock in the same transaction; firestore.rules require this exact write.
      productsToCheck.forEach((item, i) => transaction.update(item.ref, { stock: snapshots[i].data().stock - item.quantity, lastReservationOrderId: orderRef.id }));
      transaction.set(orderRef, order);
      transaction.set(doc(orderRef, 'private', 'contact'), contact);
    });
    window.dispatchEvent(new CustomEvent('marketly:order-placed', { detail: { ...order, id: orderRef.id, createdAt: new Date() } }));
    cart = [];
    updateCartCount();
    renderCart();
    document.querySelector('#cartModal').classList.add('hidden');
    document.querySelector('#checkoutModal').classList.add('hidden');
    document.querySelector('#checkoutForm').reset();
    alert(tr('placed'));
  } catch (error) {
    console.error('Unable to record order', error);
    const failure = error.message === 'product-missing' ? 'productMissing'
      : error.message === 'price-changed' ? 'priceChanged'
      : error.message === 'stock-unavailable' ? 'stockUnavailable'
      : error.code === 'permission-denied' ? 'orderValidationFailed' : 'checkoutFail';
    document.querySelector('#checkoutMessage').textContent = tr(failure);
  } finally { button.disabled = false; submitButton.disabled = false; }
}

window.addEventListener('marketly:signed-out', () => { cart = []; updateCartCount(); renderCart(); });
window.addEventListener('marketly:set-language', event => setLanguage(event.detail));
