# Marketly

A small modular storefront using Firebase Authentication and Firestore.

## Structure

- `src/firebase/firebase.js` — Firebase app, Auth, Firestore, and Google provider setup.
- `src/auth/auth.js` — email/password registration and sign-in, Google sign-in, and user profile writes.
- `src/dashboard/dashboard.js` — account dashboard, navigation, cart summary, and sign-out.
- `src/store/store.js` — product catalog, filters, cart, and language selection.
- `src/main.js` — app entry point and Firebase auth state handling.
- `firestore.rules` — role-based rules for profiles, orders, order contact details, products, and staff. See "Security model" below.
- `src/ui/i18n.js` — English/Arabic strings for dynamic text and the Arabic version of static page text.

## Firebase setup

1. In Firebase Console, enable **Email/Password** and **Google** under Authentication → Sign-in method.
2. Add the local development host and deployed host under Authentication → Settings → Authorized domains.
3. Create a Cloud Firestore database and deploy the included rules and indexes with `firebase deploy --only firestore:rules,firestore:indexes`.
4. Confirm the Firebase web app settings in `src/firebase/firebase.js` match your Firebase project.
5. Serve the project over HTTP (ES modules do not work from `file://`). For example, use Firebase Hosting or a local static server.

New accounts store a profile at `users/{uid}` with display name, email, country code, and timestamps. Passwords are handled by Firebase Authentication and are never written to Firestore or browser storage.

## Account features

- Checkout uses cash on delivery and collects the customer's phone number and delivery address. Orders appear under Dashboard → Order follow-up; customers can cancel while an order is still placed.
- Employee accounts confirm and pack orders. Delivery workers can claim unassigned packed orders themselves; the order's delivery fee is shown as the delivery pay. Assigned delivery accounts can mark orders delivered (which records COD as paid) or report a failed delivery.
- Employee accounts can edit catalog prices and stock quantities in the Inventory & prices panel. Inventory values are stored in `products/{productId}`; new catalog items start at zero stock until an employee sets a quantity.
- Customer accounts are created through storefront registration. Employee and delivery accounts must first be created in Firebase Authentication; then add `staff/{uid}` in Firestore with `{ "role": "employee" }` or `{ "role": "delivery" }`. The rules prevent clients from creating or changing staff roles. Do not set staff roles on customer-controlled `users/{uid}` profiles.
- Deploy the Firestore rules and indexes before using staff order workflows.
- Product prices are stored in USD and displayed in the currency mapped to the selected country. The app fetches the latest USD conversion from open.er-api.com and falls back to [Frankfurter](https://frankfurter.dev/); if neither is available or a currency is not covered, the display falls back to USD.
- The support chat is an in-page FAQ bot with English and Arabic answers; it does not connect to a human support agent.
- Firestore rules limit customers to their own orders, employees to order management, and delivery workers to orders assigned to them.

## Security model (rules enforce these, not the browser)

- **Order creation reserves inventory atomically.** Checkout reads current product prices and stock in a Firestore transaction, decrements stock, and creates the order and private contact document together. Rules validate each line against the pre-transaction product price and stock, and bind each stock decrement to that new order. Customer cancellation returns reserved stock in the same transaction. Legacy orders without `inventoryReserved` keep their previous stock behavior. Rules cannot loop, so an order may contain at most 8 distinct items (`MAX_LINES` in `store.js` must match).
- **Contact details are private.** Phone, address, name and email are stored in `users/{uid}/orders/{orderId}/private/contact`, created in the same batch as the order. Employees can read them; a delivery worker can read them only after the order is assigned to them. Orders created before this change keep their contact fields on the order document and are read as a fallback.
- **Timestamps** (`createdAt`, `updatedAt`, `deliveredAt`) must equal the server time. `statusHistory[].at` is informational only because arrays cannot hold server timestamps.
- **Assignments** can only target a `staff` document whose role is `delivery`. Roles are compared case-insensitively.
- **Catalog:** the Firestore `products` collection is the source of truth. The public demo API is only used to list starter items that an employee can save (the "Set empty stock to 10" button saves all of them). Starter items that were not saved are shown to employees as "Not in store yet".
- Legacy packed orders without an `assignedTo` field are repaired automatically the first time an employee dashboard loads.

After pulling these changes, run `firebase deploy --only firestore:rules,firestore:indexes,hosting` and test the flows with the Firebase Emulator before real use.

## Order retention (30 days)

- Every order and its `private/contact` document carry an `expiresAt` timestamp set 30 days after placement. The field is retained for completed-order cleanup, but Firestore TTL is disabled so active orders cannot expire automatically.
- `firestore.indexes.json` disables TTL for `orders` and `private`. Deploy with `firebase deploy --only firestore:indexes`; if TTL remains enabled in the project, disable the existing policies in the Firebase Console as well.
- The app deletes only finished orders (delivered, cancelled, delivery failed) older than 30 days when the customer opens the dashboard. Active orders are retained until completion; cleanup requires the customer to return to the dashboard.
- Customers see a notice and a per-order deletion date. Orders older than 30 days that existed before this feature are deleted the first time their owner opens the dashboard.
- Invoices disappear with the order. Confirm your accounting and tax record-keeping needs before launch; if you must keep totals, store daily aggregates elsewhere. Fill in `STORE_INFO` in `src/dashboard/dashboard.js` (name, address, tax ID) for invoices.
