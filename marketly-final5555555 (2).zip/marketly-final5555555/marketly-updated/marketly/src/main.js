import './ui/theme.js';
import './ui/i18n.js';
import { onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js';
import { doc, getDoc, updateDoc } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';
import { auth, db } from './firebase/firebase.js';
import './auth/auth.js';
import { showDashboard } from './dashboard/dashboard.js';
import './store/store.js';
import './support/support.js';

const authScreen = document.querySelector('#authScreen');
const shopApp = document.querySelector('#shopApp');
let activeUid = '';

async function routeUser(user, profile = null) {
  if (!user) return;
  activeUid = user.uid;
  try {
    const [staffSnapshot, profileSnapshot] = await Promise.all([
      getDoc(doc(db, 'staff', user.uid)),
      profile ? Promise.resolve(null) : getDoc(doc(db, 'users', user.uid))
    ]);
    if (activeUid !== user.uid) return;
    const role = staffSnapshot.exists() ? String(staffSnapshot.data().role || '').trim().toLowerCase() : 'customer';
    if (!['employee', 'delivery', 'admin', 'customer'].includes(role)) throw new Error('Invalid account role');
    if (role === 'delivery' && user.email && staffSnapshot.data().email !== user.email) {
      try { await updateDoc(doc(db, 'staff', user.uid), { email: user.email }); }
      catch (error) { console.warn('Could not sync delivery worker email', error); }
    }
    await showDashboard(user, profile || (profileSnapshot?.exists() ? profileSnapshot.data() : {}), role);
  } catch (error) {
    console.error('Unable to load account', error);
    if (activeUid === user.uid) await showDashboard(user, profile || {}, 'customer');
  }
}

onAuthStateChanged(auth, async user => {
  if (!user) {
    activeUid = '';
    window.dispatchEvent(new CustomEvent('marketly:signed-out'));
    authScreen.classList.remove('hidden');
    shopApp.classList.add('hidden');
    return;
  }
  if (document.body.dataset.registering === '1') return;
  await routeUser(user);
});
window.addEventListener('marketly:profile', event => routeUser(event.detail.user, event.detail.profile));
