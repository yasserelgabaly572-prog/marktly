const currencyByCountry = {
  EG: 'EGP', SA: 'SAR', AE: 'AED', US: 'USD', GB: 'GBP', FR: 'EUR', DE: 'EUR', CA: 'CAD', AU: 'AUD', IN: 'INR',
  JP: 'JPY', CN: 'CNY', CH: 'CHF', ZA: 'ZAR', NG: 'NGN', MA: 'MAD', KW: 'KWD', QA: 'QAR', BH: 'BHD', OM: 'OMR',
  JO: 'JOD', TR: 'TRY', BR: 'BRL', MX: 'MXN', SG: 'SGD', NZ: 'NZD', KR: 'KRW', PK: 'PKR', ID: 'IDR', MY: 'MYR',
  TH: 'THB', PH: 'PHP', SE: 'SEK', NO: 'NOK', DK: 'DKK', PL: 'PLN', CZ: 'CZK', HU: 'HUF', IL: 'ILS', KE: 'KES'
};
let currency = 'USD';
let rate = 1;
let rateDate = '';

export function formatMoney(amount) {
  return new Intl.NumberFormat(navigator.language || 'en', { style: 'currency', currency }).format(amount * rate);
}
export function getCurrency() { return currency; }
export function getRate() { return rate; }
export function getRateDate() { return rateDate; }

async function fetchRate(code) {
  try {
    const r = await fetch('https://open.er-api.com/v6/latest/USD');
    const d = await r.json(); const v = d?.rates?.[code];
    if (Number.isFinite(v) && v > 0) return { rate: v, date: d.time_last_update_utc || '' };
  } catch (error) { console.warn('Primary rate source failed', error); }
  const r = await fetch(`https://api.frankfurter.dev/v2/rate/usd/${code.toLowerCase()}`);
  if (!r.ok) throw new Error('Exchange rate unavailable');
  const d = await r.json(); if (!(d.rate > 0)) throw new Error('Invalid exchange rate');
  return { rate: d.rate, date: d.date || '' };
}
export async function setCurrencyForCountry(countryCode) {
  const next = currencyByCountry[countryCode] || 'USD';
  currency = next; rate = 1; rateDate = '';
  if (next !== 'USD') {
    try { const result = await fetchRate(next); rate = result.rate; rateDate = result.date; }
    catch (error) { console.warn(`Could not load ${next} rate; showing USD instead.`, error); currency = 'USD'; }
  }
  window.dispatchEvent(new CustomEvent('marketly:currency-changed', { detail: { currency, rate, rateDate } }));
  return { currency, rate, rateDate };
}
