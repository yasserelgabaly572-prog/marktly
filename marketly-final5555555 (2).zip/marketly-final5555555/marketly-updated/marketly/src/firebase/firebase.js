import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js';
import { getAuth, GoogleAuthProvider } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js';
import { getFirestore } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: 'AIzaSyCnr_4WZzVQmIaaCvDFZ06vxVOjFbXpIBk',
  authDomain: 'marketly-77ad0.firebaseapp.com',
  projectId: 'marketly-77ad0',
  storageBucket: 'marketly-77ad0.firebasestorage.app',
  messagingSenderId: '292292693545',
  appId: '1:292292693545:web:37ee86afb79105a52b1638',
  measurementId: 'G-3XKYT6RLY5'
};

export const firebaseApp = initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);
export const db = getFirestore(firebaseApp);
export const googleProvider = new GoogleAuthProvider();
