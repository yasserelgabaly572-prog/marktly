const launcher = document.querySelector('#supportLauncher');
const panel = document.querySelector('#supportChat');
const messages = document.querySelector('#chatMessages');
const form = document.querySelector('#chatForm');
const input = document.querySelector('#chatInput');

launcher.addEventListener('click', () => { panel.classList.remove('hidden'); input.focus(); });
document.querySelector('#supportClose').addEventListener('click', () => panel.classList.add('hidden'));

function answer(question) {
  const normalized = question.toLowerCase();
  const arabic = /[\u0600-\u06FF]/.test(question);
  const rules = [
    { match: /cash|\bcod\b|pay|payment|card|دفع|بطاق|كاش|نقد/, en: 'Payment is cash on delivery. Pay the delivery worker when your order arrives.', ar: 'الدفع نقدًا عند الاستلام. ادفع لمندوب التوصيل عند وصول الطلب.' },
    { match: /return|refund|استرجاع|إرجاع|استرداد/, en: 'Return and refund requests are handled by the store team. Keep your order number from Dashboard → Order follow-up when you contact them.', ar: 'يتولى فريق المتجر طلبات الاسترجاع ورد الأموال. احتفظ برقم طلبك من لوحة التحكم ← متابعة الطلب عند التواصل معهم.' },
    { match: /ship|deliver|delivery|شحن|توصيل/, en: 'Add your phone number and delivery address at checkout. Follow delivery progress from Dashboard → Order follow-up.', ar: 'أضف رقم هاتفك وعنوان التوصيل عند إتمام الطلب، وتابع حالته من لوحة التحكم ← متابعة الطلب.' },
    { match: /order|purchase|history|طلب|شراء|سجل/, en: 'Open Dashboard → Order follow-up to check your order status. You can cancel while it is still marked Received.', ar: 'افتح لوحة التحكم ثم متابعة الطلب لمراجعة حالته. يمكنك إلغاء الطلب ما دامت حالته «تم الاستلام».' },
    { match: /currency|price|عملة|سعر|أسعار/, en: 'Prices use your country’s currency when a current exchange rate is available. Otherwise, prices fall back to USD.', ar: 'تُعرض الأسعار بعملة دولتك عند توفر سعر صرف حديث، وإلا فستظهر بالدولار الأمريكي.' },
    { match: /account|profile|حساب|ملف/, en: 'Your profile and country are shown on the Dashboard. Sign in with the same method you used to register.', ar: 'تجد بيانات حسابك ودولتك في لوحة التحكم. سجّل الدخول بالطريقة نفسها التي استخدمتها عند إنشاء الحساب.' }
  ];
  return rules.find(rule => rule.match.test(normalized))?.[arabic ? 'ar' : 'en'] || (arabic ? 'أقدر أساعدك في الطلبات والشحن والاسترجاع والدفع والعملة والحساب. اكتب سؤالك بإحدى هذه الكلمات.' : 'I can help with orders, shipping, returns, payment, currency, or your account. Try asking about one of those topics.');
}

function addMessage(text, type) {
  const bubble = document.createElement('p');
  bubble.className = `chat-bubble ${type}`;
  bubble.textContent = text;
  messages.append(bubble);
  messages.scrollTop = messages.scrollHeight;
}

form.addEventListener('submit', event => {
  event.preventDefault();
  const question = input.value.trim();
  if (!question) return;
  addMessage(question, 'user');
  addMessage(answer(question), 'bot');
  input.value = '';
  input.focus();
});
