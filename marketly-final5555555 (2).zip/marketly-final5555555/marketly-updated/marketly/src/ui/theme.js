const ar = () => (localStorage.getItem('marketlyLanguage') || 'en') === 'ar';
const themes = [['sage', 'Fresh sage', 'سيج هادئ', '#14211d', '#d9f36d'], ['souq', 'Warm souq', 'دافئ', '#1f2a44', '#e0a526'], ['night', 'Night mode', 'ليلي', '#0f1115', '#8b7bff']];
function apply(theme) { document.documentElement.dataset.theme = theme; try { localStorage.setItem('marketlyTheme', theme); } catch (error) { console.warn(error); } document.querySelectorAll('[data-theme-choice]').forEach(b => b.classList.toggle('active', b.dataset.themeChoice === theme)); }
function picker() {
  const box = document.createElement('section'); box.className = 'order-history theme-picker';
  box.innerHTML = `<div class="history-heading"><div><p class="eyebrow">${ar() ? 'المظهر' : 'APPEARANCE'}</p><h2>${ar() ? 'إعدادات الشكل' : 'Appearance'}</h2></div></div><div class="theme-options"></div><label class="language-setting"><span>${ar() ? 'اللغة' : 'Language'}</span><select data-language-select aria-label="Language"><option value="en">English</option><option value="fr">Français</option><option value="ar">العربية</option><option value="es">Español</option></select></label>`;
  themes.forEach(([id, en, arabic, c1, c2]) => { const b = document.createElement('button'); b.type = 'button'; b.dataset.themeChoice = id; b.innerHTML = `<span style="background:${c1}"></span><span style="background:${c2}"></span>${ar() ? arabic : en}`; b.addEventListener('click', () => apply(id)); box.querySelector('.theme-options').append(b); });
  const select = box.querySelector('[data-language-select]'); select.value = localStorage.getItem('marketlyLanguage') || 'en';
  select.addEventListener('change', () => window.dispatchEvent(new CustomEvent('marketly:set-language', { detail: select.value })));
  return box;
}
apply(localStorage.getItem('marketlyTheme') || 'sage');
function mountPickers() {
  document.querySelectorAll('.theme-picker').forEach(node => node.remove());
  document.querySelector('#dashboardView')?.append(picker());
  document.querySelector('#staffView')?.append(picker());
  apply(document.documentElement.dataset.theme);
}
window.addEventListener('marketly:language-changed', mountPickers);
mountPickers();
