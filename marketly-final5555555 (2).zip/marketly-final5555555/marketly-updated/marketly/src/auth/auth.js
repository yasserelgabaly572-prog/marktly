import { auth, db, googleProvider } from '../firebase/firebase.js';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup, updateProfile } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js';
import { doc, getDoc, setDoc, serverTimestamp } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';

const form = document.querySelector('#authForm');
const message = document.querySelector('#authMessage');
let isSignUp = false;

function setMode(signUp) {
  isSignUp = signUp;
  document.querySelector('#nameField').classList.toggle('hidden', !signUp);

  document.querySelector('#nameInput').required = signUp;
  document.querySelector('#countryInput').required = signUp;
  document.querySelector('#passwordInput').autocomplete = signUp ? 'new-password' : 'current-password';
  document.querySelector('#authTitle').textContent = signUp ? 'Create your account' : 'Sign in to continue';
  document.querySelector('#authSubtitle').textContent = signUp ? 'A better way to find everyday favorites.' : 'Your next favorite thing is waiting.';
  document.querySelector('#authSubmit').firstChild.textContent = signUp ? 'Create account ' : 'Sign in ';
  document.querySelector('#switchPrompt').textContent = signUp ? 'Already have an account?' : 'New to Marketly?';
  document.querySelector('#switchAuth').textContent = signUp ? 'Sign in' : 'Create an account';
  message.textContent = '';
}

async function ensureProfile(user, country = '') {
  const userRef = doc(db, 'users', user.uid);
  const existing = await getDoc(userRef);
  const profile = { uid: user.uid, email: user.email || '', displayName: user.displayName || '', photoURL: user.photoURL || '', country: country || existing.data()?.country || '', updatedAt: serverTimestamp() };
  if (!existing.exists() || country) profile.createdAt = existing.data()?.createdAt || serverTimestamp();
  await setDoc(userRef, profile, { merge: true });
  return { ...profile, country: profile.country || '' };
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  const button = document.querySelector('#authSubmit');
  button.disabled = true;
  message.textContent = '';
  try {
    const email = document.querySelector('#emailInput').value.trim();
    const password = document.querySelector('#passwordInput').value;
    let credential;
    let country = '';
    if (isSignUp) {
      const displayName = document.querySelector('#nameInput').value.trim();
      country = document.querySelector('#countryInput').value;
      document.body.dataset.registering = '1';
      credential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(credential.user, { displayName });
    } else credential = await signInWithEmailAndPassword(auth, email, password);
    const profile = await ensureProfile(credential.user, country);
    window.dispatchEvent(new CustomEvent('marketly:profile', { detail: { user: credential.user, profile } }));
    form.reset();
  } catch (error) {
    message.textContent = error.code?.startsWith('auth/') ? authError(error.code) : 'Could not save your profile. Please try again.';
    if (auth.currentUser && !error.code?.startsWith('auth/')) window.dispatchEvent(new CustomEvent('marketly:profile', { detail: { user: auth.currentUser, profile: {} } }));
  } finally { delete document.body.dataset.registering; button.disabled = false; }
});

document.querySelector('#googleSignIn').addEventListener('click', async () => {
  const button = document.querySelector('#googleSignIn');
  button.disabled = true;
  message.textContent = '';
  try {
    const country = document.querySelector('#countryInput').value;
    const result = await signInWithPopup(auth, googleProvider);
    if ((await getDoc(doc(db, 'staff', result.user.uid))).exists()) return; // staff accounts are routed by onAuthStateChanged
    const known = (await getDoc(doc(db, 'users', result.user.uid))).data()?.country;
    if (!known && !country) { await auth.signOut(); message.textContent = 'Choose your country first, then continue with Google.'; return; }
    const profile = await ensureProfile(result.user, known ? '' : country);
    window.dispatchEvent(new CustomEvent('marketly:profile', { detail: { user: result.user, profile } }));
  } catch (error) { message.textContent = error.code?.startsWith('auth/') ? authError(error.code) : 'Could not sign in with Google. Please try again.'; }
  finally { button.disabled = false; }
});

document.querySelector('#switchAuth').addEventListener('click', () => setMode(!isSignUp));

function authError(code) {
  const errors = {
    'auth/email-already-in-use': 'This email is already registered. Sign in instead.',
    'auth/invalid-email': 'Enter a valid email address.',
    'auth/invalid-credential': 'Email or password is incorrect.',
    'auth/weak-password': 'Choose a password with at least 6 characters.',
    'auth/popup-closed-by-user': 'Google sign-in was cancelled.',
    'auth/unauthorized-domain': 'Add this site domain to Firebase Authentication authorized domains.'
  };
  return errors[code] || 'Authentication failed. Please try again.';
}

export { ensureProfile };
